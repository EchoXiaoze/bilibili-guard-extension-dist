(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime) throw new Error('Bilibili guard namespace is not initialized');

  const STORAGE_KEY = 'bilibiliGuardPanelUi';
  const VERSION = 1;
  const MARGIN = 8;
  const DEFAULT_TOP = 96;
  const DEFAULT_RIGHT = 16;
  const fallback = () => ({version: VERSION, left: null, top: null, minimized: false});

  function finite(value) {
    return typeof value === 'number' && Number.isFinite(value) ? value : null;
  }

  function normalizeStoredState(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== VERSION) {
      return fallback();
    }
    return {
      version: VERSION,
      left: finite(value.left),
      top: finite(value.top),
      minimized: typeof value.minimized === 'boolean' ? value.minimized : false,
    };
  }

  function clampPosition(position, geometry) {
    const visibleHeight = Math.min(
      geometry.panelHeight,
      Math.max(geometry.headerHeight, geometry.viewportHeight - (MARGIN * 2)),
    );
    const maxLeft = Math.max(MARGIN, geometry.viewportWidth - geometry.panelWidth - MARGIN);
    const maxTop = Math.max(MARGIN, geometry.viewportHeight - visibleHeight - MARGIN);
    return {
      left: Math.min(maxLeft, Math.max(MARGIN, finite(position.left) ?? MARGIN)),
      top: Math.min(maxTop, Math.max(MARGIN, finite(position.top) ?? MARGIN)),
    };
  }

  function resolveState(value, geometry) {
    const state = normalizeStoredState(value);
    const initial = {
      left: state.left ?? Math.max(MARGIN, geometry.viewportWidth - geometry.panelWidth - DEFAULT_RIGHT),
      top: state.top ?? DEFAULT_TOP,
    };
    return {version: VERSION, ...clampPosition(initial, geometry), minimized: state.minimized};
  }

  function createStore({storageArea}) {
    if (!storageArea?.get || !storageArea?.set) throw new TypeError('Storage area is invalid');
    return Object.freeze({
      async load() {
        try {
          const record = await storageArea.get(STORAGE_KEY);
          return normalizeStoredState(record?.[STORAGE_KEY]);
        } catch {
          return fallback();
        }
      },
      async save(value) {
        try {
          const state = normalizeStoredState(value);
          if (state.left === null || state.top === null) return false;
          await storageArea.set({[STORAGE_KEY]: state});
          return true;
        } catch {
          return false;
        }
      },
    });
  }

  runtime.panelState = Object.freeze({
    STORAGE_KEY, normalizeStoredState, clampPosition, resolveState, createStore,
  });
})();
