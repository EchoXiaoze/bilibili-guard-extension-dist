(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime) throw new Error('Bilibili guard namespace is not initialized');

  const VERSION_PATTERN = /^(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*)){0,3}$/u;

  function parse(value) {
    if (typeof value !== 'string' || !VERSION_PATTERN.test(value)) return null;
    const parts = value.split('.').map(Number);
    if (parts.some(part => !Number.isSafeInteger(part) || part < 0 || part > 65535)) return null;
    while (parts.length < 4) parts.push(0);
    return Object.freeze(parts);
  }

  function compare(leftValue, rightValue) {
    const left = parse(leftValue);
    const right = parse(rightValue);
    if (!left || !right) throw new TypeError('Versions must contain one to four bounded numeric segments');
    for (let index = 0; index < 4; index += 1) {
      if (left[index] > right[index]) return 1;
      if (left[index] < right[index]) return -1;
    }
    return 0;
  }

  function isNewer(candidate, current) {
    return compare(candidate, current) > 0;
  }

  runtime.version = Object.freeze({parse, compare, isNewer});
})();
