(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts || !runtime.version) {
    throw new Error('Bilibili guard update dependencies are not initialized');
  }

  const {createError} = runtime.contracts;
  const TOP_LEVEL_KEYS = new Set([
    'schemaVersion',
    'version',
    'sourceCommit',
    'publishedAt',
    'userscriptUrl',
    'extensionUrl',
    'sha256',
  ]);
  const HASH_KEYS = new Set(['userscript', 'extension']);
  const SHA256_PATTERN = /^[0-9a-f]{64}$/u;
  const COMMIT_PATTERN = /^[0-9a-f]{40}$/u;
  const UTC_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/u;

  function exactKeys(value, keys) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const actual = Object.keys(value);
    return actual.length === keys.size && actual.every(key => keys.has(key));
  }

  function fail() {
    throw createError('update_manifest_invalid');
  }

  function normalize(value, allowedBaseUrl) {
    if (!exactKeys(value, TOP_LEVEL_KEYS) || value.schemaVersion !== 1) fail();
    if (!runtime.version.parse(value.version)) fail();
    if (typeof value.sourceCommit !== 'string' || !COMMIT_PATTERN.test(value.sourceCommit)) fail();
    if (typeof value.publishedAt !== 'string' || !UTC_PATTERN.test(value.publishedAt)) fail();
    const parsedTime = new Date(value.publishedAt);
    if (Number.isNaN(parsedTime.valueOf()) || parsedTime.toISOString() !== value.publishedAt.replace(/Z$/u, '.000Z')) fail();
    if (typeof allowedBaseUrl !== 'string' || !allowedBaseUrl.endsWith('/')) fail();
    let base;
    try {
      base = new URL(allowedBaseUrl);
    } catch {
      fail();
    }
    if (base.protocol !== 'https:' || base.href !== allowedBaseUrl) fail();
    const expectedUserscript = `${allowedBaseUrl}userscript/bilibili-guard.user.js`;
    const expectedExtension = `${allowedBaseUrl}extension/bilibili-guard-extension.zip`;
    if (value.userscriptUrl !== expectedUserscript || value.extensionUrl !== expectedExtension) fail();
    if (!exactKeys(value.sha256, HASH_KEYS)) fail();
    if (!SHA256_PATTERN.test(value.sha256.userscript) || !SHA256_PATTERN.test(value.sha256.extension)) fail();

    return Object.freeze({
      schemaVersion: 1,
      version: value.version,
      sourceCommit: value.sourceCommit,
      publishedAt: value.publishedAt,
      userscriptUrl: value.userscriptUrl,
      extensionUrl: value.extensionUrl,
      sha256: Object.freeze({
        userscript: value.sha256.userscript,
        extension: value.sha256.extension,
      }),
    });
  }

  runtime.updateManifest = Object.freeze({normalize});
})();
