(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts) throw new Error('Bilibili guard contracts are not initialized');

  const {createError, normalizeHttpsUrl, normalizePositiveInteger, normalizeUid} = runtime.contracts;
  const TIERS = Object.freeze({
    1: Object.freeze({name: '总督', frame: 'governor.png', level: 1}),
    2: Object.freeze({name: '提督', frame: 'admiral.png', level: 2}),
    3: Object.freeze({name: '舰长', frame: 'captain.png', level: 3}),
  });

  function guardTier(value) {
    const level = normalizePositiveInteger(value, {allowZero: true});
    return TIERS[level] ?? {name: '未知等级', frame: null, level};
  }

  function boundedText(value, maximum, fallback = '') {
    if (typeof value !== 'string') return fallback;
    const text = value.trim();
    return text ? text.slice(0, maximum) : fallback;
  }

  function optionalInteger(value, {positive = false} = {}) {
    if (value === null || value === undefined || value === '') return null;
    return normalizePositiveInteger(value, {allowZero: !positive});
  }

  function normalizeMember(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
    const uid = normalizeUid(raw.uid);
    if (!uid) return null;
    const medal = raw.medal_info && typeof raw.medal_info === 'object'
      ? raw.medal_info
      : {};
    return {
      uid,
      nickname: boundedText(raw.username, 120, `UID ${uid}`),
      avatar: normalizeHttpsUrl(raw.face),
      rank: optionalInteger(raw.rank, {positive: true}),
      guardLevel: optionalInteger(raw.guard_level) ?? 0,
      guardSubLevel: optionalInteger(raw.guard_sub_level) ?? 0,
      medalName: boundedText(medal.medal_name, 60),
      medalLevel: optionalInteger(medal.medal_level) ?? 0,
    };
  }

  function normalizeGuardPage(payload, pageNumber) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      throw createError('guard_lookup_failed');
    }
    const info = payload.info;
    if (!info || typeof info !== 'object' || Array.isArray(info)) {
      throw createError('guard_lookup_failed');
    }
    const total = normalizePositiveInteger(info.num, {allowZero: true});
    const pageCount = normalizePositiveInteger(info.page, {allowZero: true});
    const normalizedPageNumber = normalizePositiveInteger(pageNumber);
    if (
      total === null
      || pageCount === null
      || normalizedPageNumber === null
      || (total > 0 && pageCount === 0)
      || (pageCount > 0 && normalizedPageNumber > pageCount)
      || !Array.isArray(payload.top3)
      || !Array.isArray(payload.list)
    ) {
      throw createError('guard_lookup_failed');
    }
    return {
      total,
      pageCount,
      pageNumber: normalizedPageNumber,
      top3: payload.top3.map(normalizeMember).filter(Boolean),
      members: payload.list.map(normalizeMember).filter(Boolean),
    };
  }

  function memberScore(member) {
    return (member.rank === null ? 0 : 8)
      + (member.avatar ? 4 : 0)
      + (member.medalName ? 2 : 0)
      + (member.medalLevel > 0 ? 1 : 0);
  }

  function compareMembers(left, right) {
    const leftRank = left.rank ?? Number.MAX_SAFE_INTEGER;
    const rightRank = right.rank ?? Number.MAX_SAFE_INTEGER;
    if (leftRank !== rightRank) return leftRank - rightRank;
    const leftUid = BigInt(left.uid);
    const rightUid = BigInt(right.uid);
    return leftUid < rightUid ? -1 : leftUid > rightUid ? 1 : 0;
  }

  function mergeGuardPages(firstPage, remainingPages = []) {
    if (!firstPage || typeof firstPage !== 'object' || !Array.isArray(remainingPages)) {
      throw createError('details_incomplete');
    }
    if (firstPage.pageCount > 500) throw createError('details_too_large');
    if (firstPage.pageNumber !== 1) throw createError('details_incomplete');

    const pages = [firstPage, ...remainingPages];
    const expectedPageCount = Math.max(1, firstPage.pageCount);
    const seenPages = new Set();
    for (const page of pages) {
      if (
        !page
        || page.total !== firstPage.total
        || page.pageCount !== firstPage.pageCount
        || !Number.isSafeInteger(page.pageNumber)
        || page.pageNumber < 1
        || page.pageNumber > expectedPageCount
        || seenPages.has(page.pageNumber)
      ) {
        throw createError('details_incomplete');
      }
      seenPages.add(page.pageNumber);
    }
    if (seenPages.size !== expectedPageCount) throw createError('details_incomplete');

    const candidates = [
      ...firstPage.top3,
      ...firstPage.members,
      ...remainingPages.flatMap(page => page.members),
    ];
    const byUid = new Map();
    for (const member of candidates) {
      const current = byUid.get(member.uid);
      if (!current || memberScore(member) > memberScore(current)) byUid.set(member.uid, member);
    }
    const members = [...byUid.values()].sort(compareMembers);
    if (members.length !== firstPage.total) throw createError('details_incomplete');

    return {
      total: firstPage.total,
      pageCount: firstPage.pageCount,
      members,
    };
  }

  runtime.guardData = Object.freeze({
    guardTier,
    normalizeMember,
    normalizeGuardPage,
    mergeGuardPages,
  });
})();
