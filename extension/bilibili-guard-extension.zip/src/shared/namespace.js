(() => {
  if (globalThis.__BILIBILI_GUARD__) return;

  Object.defineProperty(globalThis, '__BILIBILI_GUARD__', {
    configurable: false,
    enumerable: false,
    writable: false,
    value: Object.create(null),
  });
})();
