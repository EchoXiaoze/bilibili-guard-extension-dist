(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.version || !runtime.updateManifest) {
    throw new Error('Bilibili guard extension updater dependencies are not initialized');
  }

  const PUBLIC_BASE = 'https://echoxiaoze.github.io/bilibili-guard-extension-dist/';
  const MANIFEST_URL = `${PUBLIC_BASE}latest.json`;
  const STORAGE_KEY = 'bilibiliGuardUpdateState';
  const ALARM_NAME = 'bilibiliGuardUpdateCheck';
  const PERIOD_MINUTES = 360;
  const MAX_BODY_BYTES = 64 * 1024;

  function create({fetchImpl, storageArea, alarms, currentVersion, now, timeoutMs = 8000}) {
    if (
      typeof fetchImpl !== 'function'
      || !storageArea?.get
      || !storageArea?.set
      || typeof alarms?.create !== 'function'
      || !runtime.version.parse(currentVersion)
      || typeof now !== 'function'
      || !Number.isSafeInteger(timeoutMs)
      || timeoutMs <= 0
    ) {
      throw new TypeError('Extension updater dependencies are invalid');
    }

    const emptyState = () => ({
      checkedAt: 0,
      currentVersion,
      available: false,
      version: currentVersion,
      extensionUrl: null,
      error: null,
    });

    function normalizeState(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return emptyState();
      const checkedAt = Number.isSafeInteger(value.checkedAt) && value.checkedAt >= 0 ? value.checkedAt : 0;
      const version = runtime.version.parse(value.version) ? value.version : currentVersion;
      const available = value.available === true && runtime.version.isNewer(version, currentVersion);
      const extensionUrl = available
        && value.extensionUrl === `${PUBLIC_BASE}extension/bilibili-guard-extension.zip`
        ? value.extensionUrl
        : null;
      return {
        checkedAt,
        currentVersion,
        available: Boolean(available && extensionUrl),
        version: available && extensionUrl ? version : currentVersion,
        extensionUrl,
        error: value.error === 'update_check_failed' ? 'update_check_failed' : null,
      };
    }

    async function getStatus() {
      try {
        return normalizeState((await storageArea.get(STORAGE_KEY))?.[STORAGE_KEY]);
      } catch {
        return emptyState();
      }
    }

    async function save(state) {
      const normalized = normalizeState(state);
      try { await storageArea.set({[STORAGE_KEY]: normalized}); } catch { /* status persistence is best effort */ }
      return normalized;
    }

    async function fetchManifest() {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const response = await fetchImpl(MANIFEST_URL, {
          method: 'GET',
          credentials: 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (!response?.ok) throw new Error('Update request failed');
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_BODY_BYTES) throw new Error('Update response invalid');
        return runtime.updateManifest.normalize(JSON.parse(text), PUBLIC_BASE);
      } finally {
        clearTimeout(timeout);
      }
    }

    async function check() {
      const previous = await getStatus();
      try {
        const manifest = await fetchManifest();
        const available = runtime.version.isNewer(manifest.version, currentVersion);
        return save({
          checkedAt: now(),
          currentVersion,
          available,
          version: available ? manifest.version : currentVersion,
          extensionUrl: available ? manifest.extensionUrl : null,
          error: null,
        });
      } catch {
        return Object.freeze({...previous, error: 'update_check_failed'});
      }
    }

    async function initialize() {
      alarms.create(ALARM_NAME, {periodInMinutes: PERIOD_MINUTES});
      return getStatus();
    }

    async function handleAlarm(alarm) {
      if (alarm?.name !== ALARM_NAME) return false;
      await check();
      return true;
    }

    async function handleMessage(message) {
      if (message?.type === 'update.status.get') return {ok: true, update: await getStatus()};
      if (message?.type === 'update.check') return {ok: true, update: await check()};
      return null;
    }

    return Object.freeze({initialize, check, getStatus, handleAlarm, handleMessage});
  }

  runtime.updater = Object.freeze({
    PUBLIC_BASE,
    MANIFEST_URL,
    STORAGE_KEY,
    ALARM_NAME,
    PERIOD_MINUTES,
    create,
  });
})();
