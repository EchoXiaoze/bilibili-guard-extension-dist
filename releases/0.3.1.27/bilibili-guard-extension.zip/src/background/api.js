(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts) throw new Error('Bilibili guard contracts are not initialized');

  const {
    createError,
    normalizeBvid,
    normalizeHttpsUrl,
    normalizePositiveInteger,
    normalizeUid,
  } = runtime.contracts;
  const ENDPOINTS = Object.freeze({
    view: 'https://api.bilibili.com/x/web-interface/view',
    room: 'https://api.live.bilibili.com/room/v1/Room/get_status_info_by_uids',
    guard: 'https://api.live.bilibili.com/xlive/app-room/v2/guardTab/topList',
    ipLocation: 'https://api.gscn.live/bw/api/public/bilibili/ip-location',
    streamRevenue: 'https://api.vtb.cat/liver/space',
  });
  const MAX_BODY_BYTES = 2 * 1024 * 1024;
  const MAX_IP_LOCATION_BODY_BYTES = 16 * 1024;
  const IP_LOCATION_TIMEOUT_MS = 2500;
  const MAX_STREAM_REVENUE_BODY_BYTES = 512 * 1024;
  const STREAM_REVENUE_TIMEOUT_MS = 4000;
  const MAX_STREAM_REVENUE = 100_000_000;
  const IP_LOCATION_STATUSES = new Set([
    'found',
    'no_location',
    'auth_required',
    'risk_control',
  ]);
  const IP_LOCATION_STATUS_ALIASES = Object.freeze({
    credential_expired: 'auth_required',
    risk_controlled: 'risk_control',
  });
  const IP_LOCATION_SOURCES = new Set(['space_tag', 'space_tag_bottom']);

  function displayName(value, uid) {
    if (typeof value !== 'string') return `UID ${uid}`;
    const text = value.trim();
    return text ? text.slice(0, 120) : `UID ${uid}`;
  }

  function retryDelay(response) {
    if (response.status !== 429) return 1000;
    const raw = response.headers?.get?.('Retry-After');
    if (typeof raw !== 'string' || !/^[1-5]$/u.test(raw.trim())) return 1000;
    return Number(raw.trim()) * 1000;
  }

  function nonNegativeRevenue(value) {
    const number = typeof value === 'number'
      ? value
      : typeof value === 'string' && /^\d+(?:\.\d{1,2})?$/u.test(value.trim())
        ? Number(value)
        : NaN;
    return Number.isFinite(number) && number >= 0 && number <= MAX_STREAM_REVENUE
      ? number
      : null;
  }

  function parseCharge(value) {
    let charges = value;
    if (typeof charges === 'string') {
      try {
        charges = JSON.parse(charges);
      } catch {
        return null;
      }
    }
    if (!Array.isArray(charges) || charges.length > 1000) return null;
    let total = 0;
    for (const charge of charges) {
      if (!charge || typeof charge !== 'object' || Array.isArray(charge)) return null;
      const count = nonNegativeRevenue(charge.Count ?? charge.count);
      const price = nonNegativeRevenue(charge.Price ?? charge.price);
      if (count === null || price === null || !Number.isInteger(count)) return null;
      total += count * price;
      if (!Number.isFinite(total) || total > MAX_STREAM_REVENUE) return null;
    }
    return total;
  }

  function normalizeStreamRevenuePayload(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    const data = payload.data && typeof payload.data === 'object' && !Array.isArray(payload.data)
      ? payload.data
      : payload;
    const amount = nonNegativeRevenue(data.Amount ?? data.amount);
    if (amount === null) {
      return {status: 'no_data', total: null, giftSc: null, guard: null, charge: null};
    }
    const guard = nonNegativeRevenue(data.GuardSum ?? data.guardSum);
    const charge = parseCharge(data.Charge ?? data.charge);
    if (guard === null || charge === null || guard > amount) {
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    const giftSc = amount - guard;
    const total = amount + charge;
    if (!Number.isFinite(total) || total > MAX_STREAM_REVENUE) {
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    return {status: 'found', total, giftSc, guard, charge};
  }

  function createBilibiliApi({fetchImpl, sleep, timeoutMs = 8000}) {
    if (
      typeof fetchImpl !== 'function'
      || typeof sleep !== 'function'
      || !Number.isSafeInteger(timeoutMs)
      || timeoutMs <= 0
    ) {
      throw new TypeError('Bilibili API dependencies are invalid');
    }

    async function requestJson(url, failureCode) {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        try {
          const response = await fetchImpl(url.href, {
            method: 'GET',
            credentials: 'omit',
            redirect: 'error',
            cache: 'no-store',
            signal: controller.signal,
          });

          if (response.status === 429 || response.status >= 500) {
            if (attempt === 0) {
              await sleep(retryDelay(response));
              continue;
            }
            throw createError(failureCode);
          }
          if (!response.ok) throw createError(failureCode);

          const contentLength = response.headers?.get?.('content-length');
          if (contentLength !== null && contentLength !== undefined) {
            const size = Number(contentLength);
            if (!Number.isFinite(size) || size < 0 || size > MAX_BODY_BYTES) {
              throw createError(failureCode);
            }
          }
          const text = await response.text();
          if (typeof text !== 'string' || text.length > MAX_BODY_BYTES) {
            throw createError(failureCode);
          }
          let payload;
          try {
            payload = JSON.parse(text);
          } catch {
            throw createError(failureCode);
          }
          if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
            throw createError(failureCode);
          }
          if (payload.code === -352 || payload.code === -412) {
            throw createError('risk_controlled');
          }
          if (payload.code !== 0) throw createError(failureCode);
          return payload;
        } catch (error) {
          if (controller.signal.aborted) throw createError('request_timeout');
          if (error?.code) throw error;
          if (attempt === 0) {
            await sleep(1000);
            continue;
          }
          throw createError(failureCode);
        } finally {
          clearTimeout(timeout);
        }
      }
      throw createError(failureCode);
    }

    async function resolveVideo(bvidValue) {
      const bvid = normalizeBvid(bvidValue);
      if (!bvid) throw createError('creator_lookup_failed');
      const url = new URL(ENDPOINTS.view);
      url.searchParams.set('bvid', bvid);
      const payload = await requestJson(url, 'creator_lookup_failed');
      const owner = payload.data?.owner;
      const uid = normalizeUid(owner?.mid);
      if (!uid) throw createError('creator_lookup_failed');
      return {
        uid,
        name: displayName(owner.name, uid),
        avatar: normalizeHttpsUrl(owner.face),
      };
    }

    async function resolveRoom(uidValue) {
      const uid = normalizeUid(uidValue);
      if (!uid) throw createError('invalid_identity');
      const url = new URL(ENDPOINTS.room);
      url.searchParams.append('uids[]', uid);
      const payload = await requestJson(url, 'creator_lookup_failed');
      const room = payload.data?.[uid];
      const roomId = normalizeUid(room?.room_id);
      if (!room || !roomId) throw createError('no_live_room');
      return {
        uid,
        roomId,
        name: displayName(room.uname, uid),
        avatar: normalizeHttpsUrl(room.face),
      };
    }

    async function fetchGuardPage({roomId: roomValue, creatorUid: uidValue, page: pageValue}) {
      const roomId = normalizeUid(roomValue);
      const creatorUid = normalizeUid(uidValue);
      const page = normalizePositiveInteger(pageValue);
      if (!roomId || !creatorUid || !page) throw createError('invalid_identity');
      const url = new URL(ENDPOINTS.guard);
      url.searchParams.set('roomid', roomId);
      url.searchParams.set('ruid', creatorUid);
      url.searchParams.set('page', String(page));
      url.searchParams.set('page_size', '10');
      const payload = await requestJson(url, 'guard_lookup_failed');
      if (!payload.data || typeof payload.data !== 'object' || Array.isArray(payload.data)) {
        throw createError('guard_lookup_failed');
      }
      return payload.data;
    }

    async function fetchIpLocation(uidValue) {
      const unavailable = Object.freeze({status: 'unavailable', location: ''});
      const uid = normalizeUid(uidValue);
      if (!uid) return unavailable;
      const url = new URL(ENDPOINTS.ipLocation);
      url.searchParams.set('uid', uid);
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        Math.min(timeoutMs, IP_LOCATION_TIMEOUT_MS),
      );
      try {
        const response = await fetchImpl(url.href, {
          method: 'GET',
          credentials: 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (!response?.ok) return unavailable;
        const contentLength = response.headers?.get?.('content-length');
        if (contentLength !== null && contentLength !== undefined) {
          const size = Number(contentLength);
          if (!Number.isFinite(size) || size < 0 || size > MAX_IP_LOCATION_BODY_BYTES) {
            return unavailable;
          }
        }
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_IP_LOCATION_BODY_BYTES) {
          return unavailable;
        }
        let payload;
        try {
          payload = JSON.parse(text);
        } catch {
          return unavailable;
        }
        if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return unavailable;
        const normalizedStatus = IP_LOCATION_STATUS_ALIASES[payload.status] ?? payload.status;
        const status = IP_LOCATION_STATUSES.has(normalizedStatus)
          ? normalizedStatus
          : 'unavailable';
        if (status !== 'found') return Object.freeze({status, location: ''});
        if (typeof payload.location !== 'string') return unavailable;
        const location = payload.location.trim().slice(0, 60);
        if (!location) return unavailable;
        const result = {status, location};
        if (IP_LOCATION_SOURCES.has(payload.source)) result.source = payload.source;
        return Object.freeze(result);
      } catch {
        return unavailable;
      } finally {
        clearTimeout(timeout);
      }
    }

    function isCloudflareChallenge(response) {
      return response?.headers?.get?.('cf-mitigated')?.trim().toLowerCase() === 'challenge';
    }

    async function fetchStreamRevenue(uidValue, {includeVerificationCookies = false} = {}) {
      const unavailable = Object.freeze({
        status: 'unavailable', total: null, giftSc: null, guard: null, charge: null,
      });
      const uid = normalizeUid(uidValue);
      if (!uid || typeof includeVerificationCookies !== 'boolean') return unavailable;
      const url = new URL(ENDPOINTS.streamRevenue);
      url.searchParams.set('uid', uid);
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        Math.min(timeoutMs, STREAM_REVENUE_TIMEOUT_MS),
      );
      try {
        const response = await fetchImpl(url.href, {
          method: 'GET',
          credentials: includeVerificationCookies ? 'include' : 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (isCloudflareChallenge(response)) {
          return Object.freeze({
            status: 'verification_required', total: null, giftSc: null, guard: null, charge: null,
          });
        }
        if (!response?.ok) return unavailable;
        const contentLength = response.headers?.get?.('content-length');
        if (contentLength !== null && contentLength !== undefined) {
          const size = Number(contentLength);
          if (!Number.isFinite(size) || size < 0 || size > MAX_STREAM_REVENUE_BODY_BYTES) {
            return unavailable;
          }
        }
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_STREAM_REVENUE_BODY_BYTES) {
          return unavailable;
        }
        let payload;
        try {
          payload = JSON.parse(text);
        } catch {
          return unavailable;
        }
        return Object.freeze(normalizeStreamRevenuePayload(payload));
      } catch {
        return unavailable;
      } finally {
        clearTimeout(timeout);
      }
    }

    return Object.freeze({resolveVideo, resolveRoom, fetchGuardPage, fetchIpLocation, fetchStreamRevenue});
  }

  runtime.api = Object.freeze({ENDPOINTS, createBilibiliApi});
})();
