(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts || !runtime.pageContext) {
    throw new Error('Bilibili guard content dependencies are not initialized');
  }

  const {
    createError,
    ERROR_CODES,
    normalizeHttpsUrl,
    normalizePositiveInteger,
    normalizeUid,
    parsePageUrl,
  } = runtime.contracts;
  const CACHE_STATES = new Set(['network', 'fresh', 'stale']);
  const IP_LOCATION_STATUSES = new Set([
    'no_location',
    'auth_required',
    'risk_control',
    'unavailable',
  ]);
  const STREAM_REVENUE_STATUSES = new Set(['no_data', 'unavailable', 'verification_required']);
  const LIVER_GUILD_STATUSES = new Set(['no_data', 'unavailable']);

  function boundedText(value, maximum, fallback) {
    if (typeof value !== 'string') return fallback;
    const text = value.trim();
    return text ? text.slice(0, maximum) : fallback;
  }

  function normalizeCreator(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw createError('guard_lookup_failed');
    }
    const uid = normalizeUid(value.uid);
    const roomId = normalizeUid(value.roomId);
    if (!uid || !roomId) throw createError('guard_lookup_failed');
    return {
      uid,
      roomId,
      name: boundedText(value.name, 120, `UID ${uid}`),
      avatar: normalizeHttpsUrl(value.avatar),
    };
  }

  function normalizeCacheState(value) {
    if (!CACHE_STATES.has(value)) throw createError('guard_lookup_failed');
    return value;
  }

  function normalizeIpLocation(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return {status: 'unavailable', location: ''};
    }
    if (value.status === 'found') {
      const location = boundedText(value.location, 60, '');
      if (!location) return {status: 'unavailable', location: ''};
      const result = {status: 'found', location};
      if (value.source === 'space_tag' || value.source === 'space_tag_bottom') {
        result.source = value.source;
      }
      return result;
    }
    if (IP_LOCATION_STATUSES.has(value.status)) {
      return {status: value.status, location: ''};
    }
    return {status: 'unavailable', location: ''};
  }

  function normalizeStreamRevenue(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    if (value.status === 'found') {
      const {total, giftSc, guard, charge} = value;
      if (
        [total, giftSc, guard, charge].every(number =>
          typeof number === 'number' && Number.isFinite(number) && number >= 0 && number <= 100_000_000,
        )
        && Math.abs((giftSc + guard + charge) - total) <= 0.000001
      ) {
        return {status: 'found', total, giftSc, guard, charge};
      }
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    if (STREAM_REVENUE_STATUSES.has(value.status)) {
      return {status: value.status, total: null, giftSc: null, guard: null, charge: null};
    }
    return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
  }

  function normalizeLiverGuild(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return {status: 'unavailable', name: ''};
    }
    if (value.status === 'found') {
      const name = boundedText(value.name, 120, '');
      return name ? {status: 'found', name} : {status: 'unavailable', name: ''};
    }
    if (LIVER_GUILD_STATUSES.has(value.status)) return {status: value.status, name: ''};
    return {status: 'unavailable', name: ''};
  }

  function boundedRemoteText(value, maximum) {
    if (typeof value !== 'string' || /[<>]/u.test(value)) return '';
    const text = value.replace(/[\u0000-\u001f\u007f]/gu, ' ').replace(/\s+/gu, ' ').trim();
    return text ? text.slice(0, maximum) : '';
  }

  function boundedAmount(value, maximum = 300_000_000) {
    return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= maximum
      ? value
      : null;
  }

  function normalizeMoreFlow(value) {
    const unavailable = {status: 'unavailable', months: []};
    if (!value || typeof value !== 'object' || Array.isArray(value)) return unavailable;
    if (value.status === 'no_data') return {status: 'no_data', months: []};
    if (value.status !== 'found' || !Array.isArray(value.months)) return unavailable;
    if (value.months.length === 0 || value.months.length > 36) return unavailable;
    const months = [];
    for (const month of value.months) {
      if (!month || typeof month !== 'object' || Array.isArray(month)) return unavailable;
      const year = normalizePositiveInteger(month.year);
      const monthNumber = normalizePositiveInteger(month.month);
      const giftSc = boundedAmount(month.giftSc);
      const guard = boundedAmount(month.guard);
      const charge = boundedAmount(month.charge);
      const total = boundedAmount(month.total);
      if (!year || !monthNumber || monthNumber > 12) return unavailable;
      if (giftSc === null || guard === null || charge === null || total === null) return unavailable;
      if (Math.abs((giftSc + guard + charge) - total) > 0.000001) return unavailable;
      months.push({year, month: monthNumber, giftSc, guard, charge, total});
    }
    return {status: 'found', months};
  }

  function normalizeMoreFansRank(value) {
    const unavailable = {status: 'unavailable', alive: null, groups: []};
    if (!value || typeof value !== 'object' || Array.isArray(value)) return unavailable;
    if (value.status === 'no_data') return {status: 'no_data', alive: 0, groups: []};
    if (value.status !== 'found') return unavailable;
    const alive = normalizePositiveInteger(value.alive);
    if (
      !alive
      || !Array.isArray(value.groups)
      || value.groups.length === 0
      || value.groups.length > 8
    ) return unavailable;
    const groups = [];
    for (const group of value.groups) {
      if (!group || typeof group !== 'object' || Array.isArray(group)) return unavailable;
      const name = boundedRemoteText(group.name, 40);
      if (!name) return unavailable;
      const medal = boundedRemoteText(group.medal, 40);
      const count = normalizePositiveInteger(group.count, {allowZero: true});
      if (count === null) return unavailable;
      groups.push({name, medal, count, self: group.self === true});
    }
    return {status: 'found', alive, groups};
  }

  function normalizeMoreRecentLive(value) {
    const unavailable = {
      status: 'unavailable',
      liveId: null,
      endedAt: null,
      messages: null,
      revenue: null,
      peakOnline: null,
      series: [],
    };
    if (!value || typeof value !== 'object' || Array.isArray(value)) return unavailable;
    if (value.status === 'no_data') return {...unavailable, status: 'no_data'};
    if (value.status !== 'found') return unavailable;
    const liveId = normalizeUid(value.liveId);
    const endedAt = value.endedAt === null ? null : normalizePositiveInteger(value.endedAt);
    const messages = normalizePositiveInteger(value.messages, {allowZero: true});
    const revenue = boundedAmount(value.revenue, 100_000_000);
    const peakOnline = value.peakOnline === null
      ? null
      : normalizePositiveInteger(value.peakOnline, {allowZero: true});
    if (!liveId || messages === null || revenue === null) return unavailable;
    if (value.endedAt !== null && endedAt === null) return unavailable;
    if (value.peakOnline !== null && peakOnline === null) return unavailable;
    if (!Array.isArray(value.series) || value.series.length > 120) return unavailable;
    const series = value.series.map(point => normalizePositiveInteger(point, {allowZero: true}));
    if (series.some(point => point === null)) return unavailable;
    return {status: 'found', liveId, endedAt, messages, revenue, peakOnline, series};
  }

  function normalizeSummary(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw createError('guard_lookup_failed');
    }
    const total = normalizePositiveInteger(value.total, {allowZero: true});
    const pageCount = normalizePositiveInteger(value.pageCount, {allowZero: true});
    const fetchedAt = normalizePositiveInteger(value.fetchedAt, {allowZero: true});
    if (total === null || pageCount === null || fetchedAt === null) {
      throw createError('guard_lookup_failed');
    }
    return {
      creator: normalizeCreator(value.creator),
      total,
      pageCount,
      fetchedAt,
      cacheState: normalizeCacheState(value.cacheState),
      ipLocation: normalizeIpLocation(value.ipLocation),
      streamRevenue: normalizeStreamRevenue(value.streamRevenue),
      liverGuild: normalizeLiverGuild(value.liverGuild),
    };
  }

  function optionalInteger(value, {positive = false} = {}) {
    if (value === null || value === undefined) return null;
    return normalizePositiveInteger(value, {allowZero: !positive});
  }

  function normalizeMember(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const uid = normalizeUid(value.uid);
    const rank = optionalInteger(value.rank, {positive: true});
    const guardLevel = optionalInteger(value.guardLevel);
    const guardSubLevel = optionalInteger(value.guardSubLevel);
    const medalLevel = optionalInteger(value.medalLevel);
    if (
      !uid
      || (value.rank !== null && value.rank !== undefined && rank === null)
      || guardLevel === null
      || guardSubLevel === null
      || medalLevel === null
    ) return null;
    return {
      uid,
      nickname: boundedText(value.nickname, 120, `UID ${uid}`),
      avatar: normalizeHttpsUrl(value.avatar),
      rank,
      guardLevel,
      guardSubLevel,
      medalName: boundedText(value.medalName, 60, ''),
      medalLevel,
    };
  }

  function normalizeDetails(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || !Array.isArray(value.members)) {
      throw createError('guard_lookup_failed');
    }
    const total = normalizePositiveInteger(value.total, {allowZero: true});
    const fetchedAt = normalizePositiveInteger(value.fetchedAt, {allowZero: true});
    const members = value.members.map(normalizeMember).filter(Boolean);
    if (total === null || fetchedAt === null || members.length !== total) {
      throw createError('details_incomplete');
    }
    return {
      creator: normalizeCreator(value.creator),
      total,
      members,
      fetchedAt,
      cacheState: normalizeCacheState(value.cacheState),
    };
  }

  function createController({
    location,
    addEventListener,
    removeEventListener,
    setInterval,
    clearInterval,
    sendMessage,
    createPanel,
    randomId,
    getUpdateStatus = async () => null,
    subscribeUpdateStatus = () => () => {},
    initialUiState = {version: 1, left: null, top: null, minimized: false},
    saveUiState = async () => true,
    lookupAnchorSign = null,
    openRevenueVerification = null,
  }) {
    if (
      !location
      || typeof sendMessage !== 'function'
      || typeof createPanel !== 'function'
      || typeof randomId !== 'function'
      || typeof subscribeUpdateStatus !== 'function'
    ) {
      throw new TypeError('Content controller dependencies are invalid');
    }

    let currentContext = null;
    let currentKey = null;
    let currentCreatorUid = null;
    let currentCreatorRoomId = null;
    let generation = 0;
    let panel = null;
    let stopWatching = null;
    let started = false;
    let destroyed = false;
    let detailsOpen = false;
    let uiState = {...initialUiState};
    let autoDetailsPendingGeneration = null;
    let updateStatusRequested = false;
    let stopWatchingUpdateStatus = null;
    let anchorSignRequestSerial = 0;

    function renderUpdateStatus(response) {
      if (destroyed || !panel || response?.ok !== true) return;
      if (response.update?.available === true) panel.renderUpdate?.(response.update);
      else panel.clearUpdate?.();
    }

    function activeContext() {
      if (!currentCreatorUid) return currentContext;
      return {
        kind: 'space',
        uid: currentCreatorUid,
        key: `space:${currentCreatorUid}`,
      };
    }

    function renderFailure(error, expectedGeneration) {
      if (destroyed || expectedGeneration !== generation || !panel) return;
      const code = ERROR_CODES.has(error?.code) ? error.code : 'guard_lookup_failed';
      if (code === 'cooldown') {
        const retryAfterMs = normalizePositiveInteger(error?.retryAfterMs) ?? 1000;
        panel.renderCooldown(retryAfterMs);
        return;
      }
      panel.renderError(code);
    }

    async function request(type) {
      if (!currentContext || !panel || destroyed) return null;
      const expectedGeneration = generation;
      const requestId = randomId();
      const message = {
        type,
        requestId,
        pageGeneration: expectedGeneration,
        context: type === 'guard.summary.get' ? currentContext : activeContext(),
        force: type === 'guard.refresh' || type === 'guard.stream-revenue.retry',
      };
      if (type === 'guard.refresh') message.detailsOpen = detailsOpen;

      let response;
      try {
        response = await sendMessage(message);
      } catch {
        renderFailure({code: 'guard_lookup_failed'}, expectedGeneration);
        return null;
      }
      if (
        destroyed
        || expectedGeneration !== generation
        || !panel
        || !response
        || response.requestId !== requestId
        || response.pageGeneration !== expectedGeneration
      ) {
        return null;
      }
      if (response.ok !== true) {
        renderFailure(response.error, expectedGeneration);
        return response;
      }

      try {
        if (response.summary) {
          const summary = normalizeSummary(response.summary);
          currentCreatorUid = summary.creator.uid;
          currentCreatorRoomId = summary.creator.roomId;
          panel.renderSummary(summary);
          if (autoDetailsPendingGeneration === expectedGeneration) {
            autoDetailsPendingGeneration = null;
            if (response.details === undefined) {
              panel.renderLoading();
              void request('guard.details.get');
            }
          }
        }
        if (response.details) {
          const details = normalizeDetails(response.details);
          currentCreatorUid = details.creator.uid;
          currentCreatorRoomId = details.creator.roomId;
          panel.renderDetails(details);
        }
        if (response.streamRevenue) {
          panel.renderStreamRevenue?.(normalizeStreamRevenue(response.streamRevenue));
        }
      } catch (error) {
        renderFailure(error, expectedGeneration);
      }
      return response;
    }

    async function onDetails() {
      detailsOpen = true;
      panel?.renderLoading();
      return request('guard.details.get');
    }

    async function onRefresh() {
      panel?.renderLoading();
      return request('guard.refresh');
    }

    async function onAnchorSign() {
      if (!currentCreatorUid || typeof lookupAnchorSign !== 'function') {
        panel?.renderAnchorSignError?.('unavailable');
        return null;
      }
      const expectedGeneration = generation;
      const serial = ++anchorSignRequestSerial;
      const uid = currentCreatorUid;
      panel?.renderAnchorSignLoading?.();
      try {
        const result = await lookupAnchorSign(uid);
        if (destroyed || generation !== expectedGeneration || serial !== anchorSignRequestSerial) return null;
        panel?.renderAnchorSignResult?.(result);
        return result;
      } catch (error) {
        if (destroyed || generation !== expectedGeneration || serial !== anchorSignRequestSerial) return null;
        const code = ['access_code_required', 'access_code_invalid', 'rate_limited'].includes(error?.code)
          ? error.code
          : 'unavailable';
        panel?.renderAnchorSignError?.(code);
        return null;
      }
    }

    function streamRevenueVerificationUrl(uid) {
      return new URL(`/liver/${encodeURIComponent(uid)}`, 'https://vtb.cat').href;
    }

    function onRevenueVerificationOpen() {
      if (!currentCreatorUid || typeof openRevenueVerification !== 'function') return false;
      try {
        openRevenueVerification(streamRevenueVerificationUrl(currentCreatorUid));
        return true;
      } catch {
        return false;
      }
    }

    async function onRevenueVerificationRetry() {
      if (!currentCreatorUid || !panel) return null;
      panel.renderRevenueVerificationLoading?.();
      return request('guard.stream-revenue.retry');
    }

    const MORE_REQUESTS = Object.freeze({
      flow: {type: 'guard.more.flow.get', key: 'moreFlow', normalize: normalizeMoreFlow},
      'fans-rank': {
        type: 'guard.more.fans-rank.get', key: 'moreFansRank', normalize: normalizeMoreFansRank,
      },
      'recent-live': {
        type: 'guard.more.recent-live.get', key: 'moreRecentLive', normalize: normalizeMoreRecentLive,
      },
    });

    async function requestMore(kind) {
      const spec = MORE_REQUESTS[kind];
      if (!spec || !currentCreatorUid || !panel || destroyed) return null;
      if (kind === 'recent-live' && !currentCreatorRoomId) {
        panel.renderMoreData?.(kind, spec.normalize(null));
        return null;
      }
      const expectedGeneration = generation;
      const requestId = randomId();
      const message = {
        type: spec.type,
        requestId,
        pageGeneration: expectedGeneration,
        context: activeContext(),
        force: false,
      };
      if (kind === 'recent-live') message.roomId = currentCreatorRoomId;
      let response;
      try {
        response = await sendMessage(message);
      } catch {
        if (!destroyed && expectedGeneration === generation) {
          panel?.renderMoreData?.(kind, spec.normalize(null));
        }
        return null;
      }
      if (
        destroyed
        || expectedGeneration !== generation
        || !panel
        || !response
        || response.requestId !== requestId
        || response.pageGeneration !== expectedGeneration
      ) {
        return null;
      }
      if (response.ok !== true) {
        panel.renderMoreData?.(kind, spec.normalize(null));
        return response;
      }
      panel.renderMoreData?.(kind, spec.normalize(response[spec.key]));
      return response;
    }

    async function onMoreData(kind) {
      return requestMore(kind);
    }

    async function persistUiState(patch) {
      uiState = {...uiState, ...patch, version: 1};
      const saved = await saveUiState(uiState);
      if (!saved && !destroyed) panel?.renderSettingsError();
      return saved;
    }

    function onMinimize(position) {
      return persistUiState({...position, minimized: true});
    }

    function onPositionChange(position) {
      return persistUiState(position);
    }

    function onShow(position) {
      if (!uiState.minimized) return null;
      const persistence = persistUiState({...position, minimized: false});
      detailsOpen = true;
      if (currentCreatorUid) {
        panel?.renderLoading();
        return request('guard.details.get');
      }
      autoDetailsPendingGeneration = generation;
      return persistence;
    }

    function ensurePanel() {
      if (panel) return;
      panel = createPanel({
        initialState: uiState,
        onDetails,
        onRefresh,
        onMinimize,
        onShow,
        onPositionChange,
        onAnchorSign: typeof lookupAnchorSign === 'function' ? onAnchorSign : null,
        onRevenueVerificationOpen: typeof openRevenueVerification === 'function'
          ? onRevenueVerificationOpen
          : null,
        onRevenueVerificationRetry: typeof openRevenueVerification === 'function'
          ? onRevenueVerificationRetry
          : null,
        onMoreData,
      });
      if (!updateStatusRequested) {
        updateStatusRequested = true;
        Promise.resolve(getUpdateStatus()).then(renderUpdateStatus).catch(() => {});
      }
    }

    function navigate(href) {
      if (destroyed) return;
      const context = parsePageUrl(href);
      const nextKey = context?.key ?? null;
      if (nextKey === currentKey) return;
      autoDetailsPendingGeneration = null;
      anchorSignRequestSerial += 1;
      generation += 1;
      currentContext = context;
      currentKey = nextKey;
      currentCreatorUid = null;
      currentCreatorRoomId = null;
      detailsOpen = false;

      if (!context) {
        panel?.destroy();
        panel = null;
        return;
      }
      ensurePanel();
      panel.renderNavigationLoading();
      void request('guard.summary.get');
    }

    function start() {
      if (started || destroyed) return;
      started = true;
      stopWatchingUpdateStatus = subscribeUpdateStatus(renderUpdateStatus);
      stopWatching = runtime.pageContext.watchLocation({
        location,
        addEventListener,
        removeEventListener,
        setInterval,
        clearInterval,
        onChange: navigate,
      });
      navigate(location.href);
    }

    function destroy() {
      if (destroyed) return;
      destroyed = true;
      autoDetailsPendingGeneration = null;
      anchorSignRequestSerial += 1;
      generation += 1;
      stopWatching?.();
      stopWatching = null;
      stopWatchingUpdateStatus?.();
      stopWatchingUpdateStatus = null;
      panel?.destroy();
      panel = null;
    }

    return Object.freeze({start, destroy});
  }

  async function bootstrap({storageArea, controllerOptions}) {
    const store = runtime.panelState.createStore({storageArea});
    const initialUiState = await store.load();
    const controller = createController({
      ...controllerOptions,
      initialUiState,
      saveUiState: state => store.save(state),
    });
    controller.start();
    return controller;
  }

  runtime.content = Object.freeze({
    bootstrap,
    createController,
    normalizeIpLocation,
    normalizeSummary,
    normalizeDetails,
    normalizeMoreFlow,
    normalizeMoreFansRank,
    normalizeMoreRecentLive,
  });

  if (globalThis.chrome?.runtime?.sendMessage && globalThis.document && runtime.panelView) {
    void bootstrap({
      storageArea: globalThis.chrome.storage.local,
      controllerOptions: {
        location: globalThis.location,
        addEventListener: globalThis.addEventListener.bind(globalThis),
        removeEventListener: globalThis.removeEventListener.bind(globalThis),
        setInterval: globalThis.setInterval.bind(globalThis),
        clearInterval: globalThis.clearInterval.bind(globalThis),
        sendMessage: message => globalThis.chrome.runtime.sendMessage(message),
        createPanel: options => runtime.panelView.createPanel({
          document: globalThis.document,
          getURL: path => globalThis.chrome.runtime.getURL(path),
          ...options,
        }),
        randomId: () => globalThis.crypto.randomUUID(),
        openRevenueVerification: url => {
          globalThis.open(url, '_blank', 'noopener,noreferrer');
        },
        getUpdateStatus: () => globalThis.chrome.runtime.sendMessage({type: 'update.status.get'}),
        subscribeUpdateStatus: listener => {
          const onChanged = (changes, areaName) => {
            const state = changes?.bilibiliGuardUpdateState?.newValue;
            if (areaName === 'local' && state) listener({ok: true, update: state});
          };
          globalThis.chrome.storage.onChanged.addListener(onChanged);
          return () => globalThis.chrome.storage.onChanged.removeListener(onChanged);
        },
      },
    }).catch(() => {});
  }
})();
