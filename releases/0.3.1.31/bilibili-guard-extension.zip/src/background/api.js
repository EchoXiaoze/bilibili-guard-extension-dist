(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts) throw new Error('Bilibili guard contracts are not initialized');

  const {
    createError,
    normalizeBvid,
    normalizeHttpsUrl,
    normalizePositiveInteger,
    normalizeUid,
  } = runtime.contracts;
  const ENDPOINTS = Object.freeze({
    view: 'https://api.bilibili.com/x/web-interface/view',
    room: 'https://api.live.bilibili.com/room/v1/Room/get_status_info_by_uids',
    guard: 'https://api.live.bilibili.com/xlive/app-room/v2/guardTab/topList',
    ipLocation: 'https://api.gscn.live/bw/api/public/bilibili/ip-location',
    streamRevenue: 'https://api.vtb.cat/liver/space',
    liverFlow: 'https://api.vtb.cat/liver/flow',
    fansRank: 'https://api.vtb.cat/fansRank',
    actions: 'https://api.vtb.cat/actions',
    liveOnline: 'https://api.vtb.cat/online',
    liverGuild: 'https://fetch.danmakus.com/https://workers.vrp.moe/laplace/bilibili-user/',
  });
  const MAX_BODY_BYTES = 2 * 1024 * 1024;
  const MAX_IP_LOCATION_BODY_BYTES = 16 * 1024;
  const IP_LOCATION_TIMEOUT_MS = 2500;
  const MAX_STREAM_REVENUE_BODY_BYTES = 2 * 1024 * 1024;
  const STREAM_REVENUE_TIMEOUT_MS = 4000;
  const MAX_STREAM_REVENUE = 100_000_000;
  const MAX_VTB_AUX_BODY_BYTES = 512 * 1024;
  const VTB_AUX_TIMEOUT_MS = 4000;
  const MAX_MONTHLY_TOTAL = 300_000_000;
  const MAX_FANS_RANK_GROUPS = 8;
  const MAX_ONLINE_POINTS = 5000;
  const MAX_ONLINE_SERIES_POINTS = 120;
  const MIN_LIVE_TIMESTAMP = 1_200_000_000;
  const MAX_LIVE_TIMESTAMP = 4_200_000_000;
  const MAX_LIVER_GUILD_BODY_BYTES = 64 * 1024;
  const LIVER_GUILD_TIMEOUT_MS = 4000;
  const IP_LOCATION_STATUSES = new Set([
    'found',
    'no_location',
    'auth_required',
    'risk_control',
  ]);
  const IP_LOCATION_STATUS_ALIASES = Object.freeze({
    credential_expired: 'auth_required',
    risk_controlled: 'risk_control',
  });
  const IP_LOCATION_SOURCES = new Set(['space_tag', 'space_tag_bottom']);

  function displayName(value, uid) {
    if (typeof value !== 'string') return `UID ${uid}`;
    const text = value.trim();
    return text ? text.slice(0, 120) : `UID ${uid}`;
  }

  function retryDelay(response) {
    if (response.status !== 429) return 1000;
    const raw = response.headers?.get?.('Retry-After');
    if (typeof raw !== 'string' || !/^[1-5]$/u.test(raw.trim())) return 1000;
    return Number(raw.trim()) * 1000;
  }

  function nonNegativeRevenue(value) {
    const number = typeof value === 'number'
      ? value
      : typeof value === 'string' && /^\d+(?:\.\d{1,2})?$/u.test(value.trim())
        ? Number(value)
        : NaN;
    return Number.isFinite(number) && number >= 0 && number <= MAX_STREAM_REVENUE
      ? number
      : null;
  }

  function nonNegativeInteger(value, maximum = MAX_STREAM_REVENUE) {
    const number = typeof value === 'number'
      ? value
      : typeof value === 'string' && /^\d+$/u.test(value.trim())
        ? Number(value)
        : NaN;
    return Number.isInteger(number) && number >= 0 && number <= maximum ? number : null;
  }

  function boundedVtbText(value) {
    if (typeof value !== 'string' || /[<>]/u.test(value)) return '';
    const text = value.replace(/[\u0000-\u001f\u007f]/gu, ' ').replace(/\s+/gu, ' ').trim();
    return text.slice(0, 40);
  }

  function normalizeLiverFlowPayload(payload) {
    const unavailable = {status: 'unavailable', months: []};
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return unavailable;
    const rows = payload.data;
    if (rows === null || rows === undefined) return {status: 'no_data', months: []};
    if (!Array.isArray(rows) || rows.length > 36) return unavailable;
    if (rows.length === 0) return {status: 'no_data', months: []};
    const months = [];
    for (const row of rows) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) return unavailable;
      const year = normalizePositiveInteger(row.Year);
      const month = normalizePositiveInteger(row.Month);
      const giftSc = nonNegativeRevenue(row.Live);
      const guard = nonNegativeRevenue(row.GuardSum);
      const charge = nonNegativeRevenue(row.Charge);
      if (!year || year < 2018 || year > 2100 || !month || month > 12) return unavailable;
      if (giftSc === null || guard === null || charge === null) return unavailable;
      const total = giftSc + guard + charge;
      if (!Number.isFinite(total) || total > MAX_MONTHLY_TOTAL) return unavailable;
      months.push({year, month, giftSc, guard, charge, total});
    }
    months.sort((left, right) => left.year - right.year || left.month - right.month);
    return {status: 'found', months};
  }

  function normalizeFansRankPayload(payload, uidValue) {
    const uid = normalizeUid(uidValue);
    const unavailable = {status: 'unavailable', alive: null, groups: []};
    if (!uid || !payload || typeof payload !== 'object' || Array.isArray(payload)) return unavailable;
    const alive = nonNegativeInteger(payload.alive);
    if (alive === null) return unavailable;
    const rows = payload.group;
    if (rows === null || rows === undefined) return {status: 'no_data', alive: 0, groups: []};
    if (!Array.isArray(rows) || rows.length > 200) return unavailable;
    const groups = [];
    for (const row of rows.slice(0, MAX_FANS_RANK_GROUPS)) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) return unavailable;
      const count = nonNegativeInteger(row.cnt);
      const name = boundedVtbText(row.liver);
      const medal = boundedVtbText(row.medal_name);
      const liverId = normalizeUid(row.liver_id);
      if (count === null || !name) return unavailable;
      groups.push({name, medal, count, self: liverId === uid});
    }
    if (alive === 0 || groups.length === 0) return {status: 'no_data', alive: 0, groups: []};
    return {status: 'found', alive, groups};
  }

  function downsampleSeries(values) {
    if (values.length <= MAX_ONLINE_SERIES_POINTS) return values;
    const stride = values.length / MAX_ONLINE_SERIES_POINTS;
    const sampled = [];
    for (let index = 0; index < MAX_ONLINE_SERIES_POINTS; index += 1) {
      sampled.push(values[Math.floor(index * stride)]);
    }
    return sampled;
  }

  function normalizeOnlinePayload(payload) {
    const rows = payload?.data;
    if (!Array.isArray(rows) || rows.length > MAX_ONLINE_POINTS) return null;
    const values = [];
    for (const row of rows) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
      const count = nonNegativeInteger(row.Count);
      if (count === null) continue;
      values.push(count);
    }
    if (values.length === 0) return null;
    return {peak: Math.max(...values), series: downsampleSeries(values)};
  }

  function normalizeLiveTimestamp(value) {
    const number = normalizePositiveInteger(value);
    if (!number || number < MIN_LIVE_TIMESTAMP || number > MAX_LIVE_TIMESTAMP) return null;
    return number;
  }

  function emptyRecentLive(status) {
    return {status, liveId: null, endedAt: null, messages: null, revenue: null};
  }

  function normalizeRecentLiveActions(payload, uidValue, roomValue) {
    const uid = normalizeUid(uidValue);
    const roomId = normalizeUid(roomValue);
    if (!uid || !roomId || !payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return emptyRecentLive('unavailable');
    }
    const lives = payload.lives;
    if (lives === null || lives === undefined) return emptyRecentLive('no_data');
    if (!Array.isArray(lives) || lives.length > 100) return emptyRecentLive('unavailable');
    const live = lives.find(item => (
      item
      && typeof item === 'object'
      && !Array.isArray(item)
      && normalizeUid(item.user_id_num) === uid
      && normalizeUid(item.room_id) === roomId
    ));
    if (!live) return emptyRecentLive('no_data');
    const liveId = normalizeUid(live.id);
    const messages = nonNegativeInteger(live.message);
    const revenue = nonNegativeRevenue(live.money);
    if (!liveId || messages === null || revenue === null) return emptyRecentLive('unavailable');
    return {
      status: 'found',
      liveId,
      endedAt: normalizeLiveTimestamp(live.end_at),
      messages,
      revenue,
    };
  }

  function parseCharge(value) {
    let charges = value;
    if (charges === null || charges === undefined) return 0;
    if (typeof charges === 'string') {
      const text = charges.trim();
      if (text === '' || text === 'null') return 0;
      try {
        charges = JSON.parse(text);
      } catch {
        return null;
      }
      if (charges === null) return 0;
    }
    if (!Array.isArray(charges) || charges.length > 1000) return null;
    let total = 0;
    for (const charge of charges) {
      if (!charge || typeof charge !== 'object' || Array.isArray(charge)) return null;
      const count = nonNegativeRevenue(charge.Count ?? charge.count);
      const price = nonNegativeRevenue(charge.Price ?? charge.price);
      if (count === null || price === null || !Number.isInteger(count)) return null;
      total += count * price;
      if (!Number.isFinite(total) || total > MAX_STREAM_REVENUE) return null;
    }
    return total;
  }

  function emptyLiverGuild(status = 'unavailable') {
    return {status, name: ''};
  }

  function normalizeLiverGuildPayload(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return emptyLiverGuild();
    }
    const guildInfo = payload.guildInfo;
    if (guildInfo === null || guildInfo === undefined) return emptyLiverGuild('no_data');
    if (!guildInfo || typeof guildInfo !== 'object' || Array.isArray(guildInfo)) {
      return emptyLiverGuild();
    }
    const history = guildInfo.history;
    if (!Array.isArray(history)) return emptyLiverGuild();
    if (history.length === 0) return emptyLiverGuild('no_data');
    if (history.length > 1000) return emptyLiverGuild();
    const latest = history.at(-1);
    if (!latest || typeof latest !== 'object' || Array.isArray(latest)) return emptyLiverGuild();
    const name = typeof latest.name === 'string' ? latest.name.trim().slice(0, 120) : '';
    return name ? {status: 'found', name} : emptyLiverGuild('no_data');
  }

  function normalizeStreamRevenuePayload(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    const data = payload.data && typeof payload.data === 'object' && !Array.isArray(payload.data)
      ? payload.data
      : payload;
    const amount = nonNegativeRevenue(data.Amount ?? data.amount);
    if (amount === null) {
      return {status: 'no_data', total: null, giftSc: null, guard: null, charge: null};
    }
    const guard = nonNegativeRevenue(data.GuardSum ?? data.guardSum);
    const charge = parseCharge(data.Charge ?? data.charge);
    if (guard === null || charge === null || guard > amount) {
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    const giftSc = amount - guard;
    const total = amount + charge;
    if (!Number.isFinite(total) || total > MAX_STREAM_REVENUE) {
      return {status: 'unavailable', total: null, giftSc: null, guard: null, charge: null};
    }
    return {status: 'found', total, giftSc, guard, charge};
  }

  function createBilibiliApi({fetchImpl, sleep, timeoutMs = 8000}) {
    if (
      typeof fetchImpl !== 'function'
      || typeof sleep !== 'function'
      || !Number.isSafeInteger(timeoutMs)
      || timeoutMs <= 0
    ) {
      throw new TypeError('Bilibili API dependencies are invalid');
    }

    async function requestJson(url, failureCode) {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        try {
          const response = await fetchImpl(url.href, {
            method: 'GET',
            credentials: 'omit',
            redirect: 'error',
            cache: 'no-store',
            signal: controller.signal,
          });

          if (response.status === 429 || response.status >= 500) {
            if (attempt === 0) {
              await sleep(retryDelay(response));
              continue;
            }
            throw createError(failureCode);
          }
          if (!response.ok) throw createError(failureCode);

          const contentLength = response.headers?.get?.('content-length');
          if (contentLength !== null && contentLength !== undefined) {
            const size = Number(contentLength);
            if (!Number.isFinite(size) || size < 0 || size > MAX_BODY_BYTES) {
              throw createError(failureCode);
            }
          }
          const text = await response.text();
          if (typeof text !== 'string' || text.length > MAX_BODY_BYTES) {
            throw createError(failureCode);
          }
          let payload;
          try {
            payload = JSON.parse(text);
          } catch {
            throw createError(failureCode);
          }
          if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
            throw createError(failureCode);
          }
          if (payload.code === -352 || payload.code === -412) {
            throw createError('risk_controlled');
          }
          if (payload.code !== 0) throw createError(failureCode);
          return payload;
        } catch (error) {
          if (controller.signal.aborted) throw createError('request_timeout');
          if (error?.code) throw error;
          if (attempt === 0) {
            await sleep(1000);
            continue;
          }
          throw createError(failureCode);
        } finally {
          clearTimeout(timeout);
        }
      }
      throw createError(failureCode);
    }

    async function resolveVideo(bvidValue) {
      const bvid = normalizeBvid(bvidValue);
      if (!bvid) throw createError('creator_lookup_failed');
      const url = new URL(ENDPOINTS.view);
      url.searchParams.set('bvid', bvid);
      const payload = await requestJson(url, 'creator_lookup_failed');
      const owner = payload.data?.owner;
      const uid = normalizeUid(owner?.mid);
      if (!uid) throw createError('creator_lookup_failed');
      return {
        uid,
        name: displayName(owner.name, uid),
        avatar: normalizeHttpsUrl(owner.face),
      };
    }

    async function resolveRoom(uidValue) {
      const uid = normalizeUid(uidValue);
      if (!uid) throw createError('invalid_identity');
      const url = new URL(ENDPOINTS.room);
      url.searchParams.append('uids[]', uid);
      const payload = await requestJson(url, 'creator_lookup_failed');
      const room = payload.data?.[uid];
      const roomId = normalizeUid(room?.room_id);
      if (!room || !roomId) throw createError('no_live_room');
      return {
        uid,
        roomId,
        name: displayName(room.uname, uid),
        avatar: normalizeHttpsUrl(room.face),
      };
    }

    async function fetchGuardPage({roomId: roomValue, creatorUid: uidValue, page: pageValue}) {
      const roomId = normalizeUid(roomValue);
      const creatorUid = normalizeUid(uidValue);
      const page = normalizePositiveInteger(pageValue);
      if (!roomId || !creatorUid || !page) throw createError('invalid_identity');
      const url = new URL(ENDPOINTS.guard);
      url.searchParams.set('roomid', roomId);
      url.searchParams.set('ruid', creatorUid);
      url.searchParams.set('page', String(page));
      url.searchParams.set('page_size', '10');
      const payload = await requestJson(url, 'guard_lookup_failed');
      if (!payload.data || typeof payload.data !== 'object' || Array.isArray(payload.data)) {
        throw createError('guard_lookup_failed');
      }
      return payload.data;
    }

    async function fetchIpLocation(uidValue) {
      const unavailable = Object.freeze({status: 'unavailable', location: ''});
      const uid = normalizeUid(uidValue);
      if (!uid) return unavailable;
      const url = new URL(ENDPOINTS.ipLocation);
      url.searchParams.set('uid', uid);
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        Math.min(timeoutMs, IP_LOCATION_TIMEOUT_MS),
      );
      try {
        const response = await fetchImpl(url.href, {
          method: 'GET',
          credentials: 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (!response?.ok) return unavailable;
        const contentLength = response.headers?.get?.('content-length');
        if (contentLength !== null && contentLength !== undefined) {
          const size = Number(contentLength);
          if (!Number.isFinite(size) || size < 0 || size > MAX_IP_LOCATION_BODY_BYTES) {
            return unavailable;
          }
        }
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_IP_LOCATION_BODY_BYTES) {
          return unavailable;
        }
        let payload;
        try {
          payload = JSON.parse(text);
        } catch {
          return unavailable;
        }
        if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return unavailable;
        const normalizedStatus = IP_LOCATION_STATUS_ALIASES[payload.status] ?? payload.status;
        const status = IP_LOCATION_STATUSES.has(normalizedStatus)
          ? normalizedStatus
          : 'unavailable';
        if (status !== 'found') return Object.freeze({status, location: ''});
        if (typeof payload.location !== 'string') return unavailable;
        const location = payload.location.trim().slice(0, 60);
        if (!location) return unavailable;
        const result = {status, location};
        if (IP_LOCATION_SOURCES.has(payload.source)) result.source = payload.source;
        return Object.freeze(result);
      } catch {
        return unavailable;
      } finally {
        clearTimeout(timeout);
      }
    }

    function isCloudflareChallenge(response) {
      return response?.headers?.get?.('cf-mitigated')?.trim().toLowerCase() === 'challenge';
    }

    async function fetchStreamRevenue(uidValue, {includeVerificationCookies = false} = {}) {
      const unavailable = Object.freeze({
        status: 'unavailable', total: null, giftSc: null, guard: null, charge: null,
      });
      const uid = normalizeUid(uidValue);
      if (!uid || typeof includeVerificationCookies !== 'boolean') return unavailable;
      const url = new URL(ENDPOINTS.streamRevenue);
      url.searchParams.set('uid', uid);
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        Math.min(timeoutMs, STREAM_REVENUE_TIMEOUT_MS),
      );
      try {
        const response = await fetchImpl(url.href, {
          method: 'GET',
          credentials: includeVerificationCookies ? 'include' : 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (isCloudflareChallenge(response)) {
          return Object.freeze({
            status: 'verification_required', total: null, giftSc: null, guard: null, charge: null,
          });
        }
        if (!response?.ok) return unavailable;
        const contentLength = response.headers?.get?.('content-length');
        if (contentLength !== null && contentLength !== undefined) {
          const size = Number(contentLength);
          if (!Number.isFinite(size) || size < 0 || size > MAX_STREAM_REVENUE_BODY_BYTES) {
            return unavailable;
          }
        }
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_STREAM_REVENUE_BODY_BYTES) {
          return unavailable;
        }
        let payload;
        try {
          payload = JSON.parse(text);
        } catch {
          return unavailable;
        }
        return Object.freeze(normalizeStreamRevenuePayload(payload));
      } catch {
        return unavailable;
      } finally {
        clearTimeout(timeout);
      }
    }

    async function fetchLiverGuild(uidValue) {
      const unavailable = Object.freeze(emptyLiverGuild());
      const uid = normalizeUid(uidValue);
      if (!uid) return unavailable;
      const url = `${ENDPOINTS.liverGuild}${uid}`;
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        Math.min(timeoutMs, LIVER_GUILD_TIMEOUT_MS),
      );
      try {
        const response = await fetchImpl(url, {
          method: 'GET',
          credentials: 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (!response?.ok) return unavailable;
        const contentLength = response.headers?.get?.('content-length');
        if (contentLength !== null && contentLength !== undefined) {
          const size = Number(contentLength);
          if (!Number.isFinite(size) || size < 0 || size > MAX_LIVER_GUILD_BODY_BYTES) {
            return unavailable;
          }
        }
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_LIVER_GUILD_BODY_BYTES) {
          return unavailable;
        }
        let payload;
        try {
          payload = JSON.parse(text);
        } catch {
          return unavailable;
        }
        return Object.freeze(normalizeLiverGuildPayload(payload));
      } catch {
        return unavailable;
      } finally {
        clearTimeout(timeout);
      }
    }

    async function requestVtbJson(url) {
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        Math.min(timeoutMs, VTB_AUX_TIMEOUT_MS),
      );
      try {
        const response = await fetchImpl(url.href, {
          method: 'GET',
          credentials: 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (!response?.ok) throw createError('guard_lookup_failed');
        const contentLength = response.headers?.get?.('content-length');
        if (contentLength !== null && contentLength !== undefined) {
          const size = Number(contentLength);
          if (!Number.isFinite(size) || size < 0 || size > MAX_VTB_AUX_BODY_BYTES) {
            throw createError('guard_lookup_failed');
          }
        }
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_VTB_AUX_BODY_BYTES) {
          throw createError('guard_lookup_failed');
        }
        const payload = JSON.parse(text);
        if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
          throw createError('guard_lookup_failed');
        }
        return payload;
      } finally {
        clearTimeout(timeout);
      }
    }

    async function fetchLiverFlow(uidValue) {
      const unavailable = Object.freeze({status: 'unavailable', months: []});
      const uid = normalizeUid(uidValue);
      if (!uid) return unavailable;
      const url = new URL(ENDPOINTS.liverFlow);
      url.searchParams.set('uid', uid);
      try {
        return Object.freeze(normalizeLiverFlowPayload(await requestVtbJson(url)));
      } catch {
        return unavailable;
      }
    }

    async function fetchFansRank(uidValue) {
      const unavailable = Object.freeze({status: 'unavailable', alive: null, groups: []});
      const uid = normalizeUid(uidValue);
      if (!uid) return unavailable;
      const url = new URL(ENDPOINTS.fansRank);
      url.searchParams.set('liver', uid);
      try {
        return Object.freeze(normalizeFansRankPayload(await requestVtbJson(url), uid));
      } catch {
        return unavailable;
      }
    }

    async function fetchRecentLive(uidValue, roomValue) {
      const unavailable = Object.freeze({
        ...emptyRecentLive('unavailable'), peakOnline: null, series: [],
      });
      const uid = normalizeUid(uidValue);
      const roomId = normalizeUid(roomValue);
      if (!uid || !roomId) return unavailable;
      const actionsUrl = new URL(ENDPOINTS.actions);
      actionsUrl.searchParams.set('uid', uid);
      actionsUrl.searchParams.set('room', roomId);
      actionsUrl.searchParams.set('pn', '1');
      actionsUrl.searchParams.set('ps', '1');
      actionsUrl.searchParams.set('order', 'time_desc');
      let base;
      try {
        base = normalizeRecentLiveActions(await requestVtbJson(actionsUrl), uid, roomId);
      } catch {
        return unavailable;
      }
      if (base.status !== 'found') {
        return Object.freeze({...base, peakOnline: null, series: []});
      }
      let online = null;
      try {
        const onlineUrl = new URL(ENDPOINTS.liveOnline);
        onlineUrl.searchParams.set('id', base.liveId);
        online = normalizeOnlinePayload(await requestVtbJson(onlineUrl));
      } catch {
        online = null;
      }
      return Object.freeze({
        ...base,
        peakOnline: online ? online.peak : null,
        series: online ? online.series : [],
      });
    }

    return Object.freeze({
      resolveVideo,
      resolveRoom,
      fetchGuardPage,
      fetchIpLocation,
      fetchStreamRevenue,
      fetchLiverGuild,
      fetchLiverFlow,
      fetchFansRank,
      fetchRecentLive,
    });
  }

  runtime.api = Object.freeze({ENDPOINTS, createBilibiliApi});
})();
