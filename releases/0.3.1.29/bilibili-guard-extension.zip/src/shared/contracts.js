(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime) throw new Error('Bilibili guard namespace is not initialized');

  const ERROR_CODES = new Set([
    'unsupported_page',
    'invalid_identity',
    'creator_lookup_failed',
    'no_live_room',
    'guard_lookup_failed',
    'risk_controlled',
    'request_timeout',
    'details_incomplete',
    'details_too_large',
    'cooldown',
    'update_manifest_invalid',
  ]);
  const MESSAGE_TYPES = new Set([
    'guard.summary.get',
    'guard.details.get',
    'guard.refresh',
    'guard.stream-revenue.retry',
  ]);
  const MAX_SAFE_ID = BigInt(Number.MAX_SAFE_INTEGER);

  function createError(code, properties = {}) {
    const safeCode = ERROR_CODES.has(code) ? code : 'guard_lookup_failed';
    const error = new Error(safeCode);
    error.code = safeCode;
    if (Number.isSafeInteger(properties.retryAfterMs) && properties.retryAfterMs > 0) {
      error.retryAfterMs = properties.retryAfterMs;
    }
    return error;
  }

  function normalizeUid(value) {
    const text = typeof value === 'number' && Number.isSafeInteger(value)
      ? String(value)
      : value;
    if (typeof text !== 'string' || !/^[1-9][0-9]{0,19}$/u.test(text)) return null;
    try {
      return BigInt(text) <= MAX_SAFE_ID ? text : null;
    } catch {
      return null;
    }
  }

  function normalizePositiveInteger(value, {allowZero = false} = {}) {
    const number = typeof value === 'string' && /^[0-9]+$/u.test(value)
      ? Number(value)
      : value;
    if (!Number.isSafeInteger(number)) return null;
    if (allowZero ? number < 0 : number <= 0) return null;
    return number;
  }

  function normalizeHttpsUrl(value) {
    if (typeof value !== 'string' || value.length > 2048) return null;
    try {
      const url = new URL(value);
      return url.protocol === 'https:' ? url.href : null;
    } catch {
      return null;
    }
  }

  function normalizeBvid(value) {
    return typeof value === 'string' && /^BV[0-9A-Za-z]{10}$/u.test(value)
      ? value
      : null;
  }

  function parsePageUrl(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      return null;
    }

    if (url.origin === 'https://www.bilibili.com') {
      const match = url.pathname.match(/^\/video\/(BV[0-9A-Za-z]{10})(?:\/|$)/u);
      if (!match) return null;
      return {kind: 'video', bvid: match[1], key: `video:${match[1]}`};
    }

    if (url.origin === 'https://space.bilibili.com') {
      const match = url.pathname.match(/^\/([1-9][0-9]{0,19})(?:\/|$)/u);
      const uid = match ? normalizeUid(match[1]) : null;
      if (!uid) return null;
      return {kind: 'space', uid, key: `space:${uid}`};
    }

    return null;
  }

  function normalizeContext(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw createError('invalid_identity');
    }
    if (value.kind === 'video') {
      const bvid = normalizeBvid(value.bvid);
      const key = bvid ? `video:${bvid}` : null;
      if (!bvid || value.key !== key) throw createError('invalid_identity');
      return {kind: 'video', bvid, key};
    }
    if (value.kind === 'space') {
      const uid = normalizeUid(value.uid);
      const key = uid ? `space:${uid}` : null;
      if (!uid || value.key !== key) throw createError('invalid_identity');
      return {kind: 'space', uid, key};
    }
    throw createError('invalid_identity');
  }

  function normalizeRequest(message) {
    if (!message || typeof message !== 'object' || Array.isArray(message)) {
      throw createError('invalid_identity');
    }
    if (!MESSAGE_TYPES.has(message.type)) throw createError('invalid_identity');
    if (
      typeof message.requestId !== 'string'
      || message.requestId.length < 1
      || message.requestId.length > 128
      || /[\u0000-\u001f\u007f]/u.test(message.requestId)
    ) {
      throw createError('invalid_identity');
    }
    if (!Number.isSafeInteger(message.pageGeneration) || message.pageGeneration < 0) {
      throw createError('invalid_identity');
    }
    if (typeof message.force !== 'boolean') throw createError('invalid_identity');
    if (message.type === 'guard.refresh' && typeof message.detailsOpen !== 'boolean') {
      throw createError('invalid_identity');
    }
    if (message.type === 'guard.stream-revenue.retry' && message.force !== true) {
      throw createError('invalid_identity');
    }

    const normalized = {
      type: message.type,
      requestId: message.requestId,
      pageGeneration: message.pageGeneration,
      context: normalizeContext(message.context),
      force: message.force,
    };
    if (message.type === 'guard.refresh') normalized.detailsOpen = message.detailsOpen;
    return normalized;
  }

  function safeError(error, request = {}) {
    const code = ERROR_CODES.has(error?.code) ? error.code : 'guard_lookup_failed';
    const requestId = typeof request.requestId === 'string' && request.requestId.length > 0
      ? request.requestId
      : null;
    const pageGeneration = Number.isSafeInteger(request.pageGeneration) && request.pageGeneration >= 0
      ? request.pageGeneration
      : 0;
    const payload = {
      ok: false,
      requestId,
      pageGeneration,
      error: {code},
    };
    if (code === 'cooldown' && Number.isSafeInteger(error?.retryAfterMs) && error.retryAfterMs > 0) {
      payload.error.retryAfterMs = error.retryAfterMs;
    }
    return payload;
  }

  runtime.contracts = Object.freeze({
    ERROR_CODES,
    createError,
    normalizeUid,
    normalizePositiveInteger,
    normalizeHttpsUrl,
    normalizeBvid,
    parsePageUrl,
    normalizeContext,
    normalizeRequest,
    safeError,
  });
})();
