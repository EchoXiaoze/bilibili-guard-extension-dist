(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts || !runtime.cache || !runtime.guardData) {
    throw new Error('Bilibili guard broker dependencies are not initialized');
  }

  const {createError, normalizeRequest} = runtime.contracts;
  const {coalesce, createSessionCache} = runtime.cache;
  const {mergeGuardPages, normalizeGuardPage} = runtime.guardData;
  const SUMMARY_TTL_MS = 60_000;
  const DETAILS_TTL_MS = 300_000;
  const STREAM_REVENUE_TTL_MS = 900_000;
  const REFRESH_COOLDOWN_MS = 60_000;

  function createGuardBroker({api, storageArea, now}) {
    if (
      !api?.resolveVideo
      || !api?.resolveRoom
      || !api?.fetchGuardPage
      || !api?.fetchIpLocation
      || !api?.fetchStreamRevenue
    ) {
      throw new TypeError('Guard broker API is invalid');
    }
    if (!storageArea?.get || !storageArea?.set || typeof now !== 'function') {
      throw new TypeError('Guard broker storage dependencies are invalid');
    }

    const sessionCache = createSessionCache({storageArea, now});
    const inFlight = new Map();

    async function identityUid(context) {
      if (context.kind === 'space') return context.uid;
      const owner = await coalesce(
        inFlight,
        `identity:${context.bvid}`,
        () => api.resolveVideo(context.bvid),
      );
      return owner.uid;
    }

    async function fetchGuardPage(creator, page) {
      await storageArea.set({[`lastNetwork:${creator.uid}`]: now()});
      const payload = await api.fetchGuardPage({
        roomId: creator.roomId,
        creatorUid: creator.uid,
        page,
      });
      return normalizeGuardPage(payload, page);
    }

    async function fetchIpLocation(uid) {
      try {
        const value = await api.fetchIpLocation(uid);
        if (!value || typeof value !== 'object' || Array.isArray(value)) {
          return {status: 'unavailable', location: ''};
        }
        if (value.status === 'found' && typeof value.location === 'string' && value.location.trim()) {
          const result = {status: 'found', location: value.location.trim().slice(0, 60)};
          if (value.source === 'space_tag' || value.source === 'space_tag_bottom') {
            result.source = value.source;
          }
          return result;
        }
        if (['no_location', 'auth_required', 'risk_control'].includes(value.status)) {
          return {status: value.status, location: ''};
        }
      } catch {
        // IP location is optional and must never block guard data.
      }
      return {status: 'unavailable', location: ''};
    }

    function normalizeStreamRevenue(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) {
        return {status: 'unavailable', total: null};
      }
      if (value.status === 'found' && typeof value.total === 'number') {
        const total = value.total;
        if (Number.isFinite(total) && total >= 0 && total <= 100_000_000) {
          return {status: 'found', total};
        }
      }
      if (value.status === 'no_data' || value.status === 'verification_required') {
        return {status: value.status, total: null};
      }
      return {status: 'unavailable', total: null};
      }

    async function fetchStreamRevenue(uid, {force = false, includeVerificationCookies = false} = {}) {
      const key = `streamRevenue:${uid}`;
      const cached = await sessionCache.read(key);
      if (!force && cached.state === 'fresh') return cached.value;
      const requestKind = includeVerificationCookies ? 'verified' : 'anonymous';
      return coalesce(inFlight, `stream-revenue:${uid}:${requestKind}`, async () => {
        const shared = await sessionCache.read(key);
        if (!force && shared.state === 'fresh') return shared.value;
        let revenue;
        try {
          revenue = normalizeStreamRevenue(await api.fetchStreamRevenue(uid, {includeVerificationCookies}));
        } catch {
          revenue = {status: 'unavailable', total: null};
        }
        await sessionCache.write(key, revenue, STREAM_REVENUE_TTL_MS);
        return revenue;
      });
    }

    async function retryVerifiedStreamRevenue(context) {
      const uid = await identityUid(context);
      const streamRevenue = await fetchStreamRevenue(uid, {
        force: true,
        includeVerificationCookies: true,
      });
      const cachedSummary = await sessionCache.read(`summary:${uid}`);
      if (cachedSummary.state !== 'missing') {
        await sessionCache.write(`summary:${uid}`, {
          ...cachedSummary.value,
          streamRevenue,
        }, SUMMARY_TTL_MS);
      }
      return {streamRevenue};
    }

    function summaryValue(creator, firstPage, ipLocation, streamRevenue, fetchedAt) {
      return {
        creator,
        total: firstPage.total,
        pageCount: firstPage.pageCount,
        fetchedAt,
        ipLocation,
        streamRevenue,
      };
    }

    async function writeSummary(creator, firstPage, ipLocation, streamRevenue) {
      const summary = summaryValue(creator, firstPage, ipLocation, streamRevenue, now());
      await sessionCache.write(`summary:${creator.uid}`, summary, SUMMARY_TTL_MS);
      return summary;
    }

    async function getSummary(context, {force = false} = {}) {
      const uid = await identityUid(context);
      const key = `summary:${uid}`;
      const cached = await sessionCache.read(key);
      if (!force && cached.state === 'fresh') {
        return {...cached.value, cacheState: 'fresh'};
      }

      return coalesce(inFlight, `summary-network:${uid}`, async () => {
        if (!force) {
          const shared = await sessionCache.read(key);
          if (shared.state === 'fresh') return {...shared.value, cacheState: 'fresh'};
        }
        const creator = await api.resolveRoom(uid);
        const [firstPage, ipLocation, streamRevenue] = await Promise.all([
          fetchGuardPage(creator, 1),
          fetchIpLocation(creator.uid),
          fetchStreamRevenue(creator.uid),
        ]);
        const summary = await writeSummary(creator, firstPage, ipLocation, streamRevenue);
        return {...summary, cacheState: 'network'};
      });
    }

    async function fetchRemainingPages(creator, pageCount) {
      if (pageCount <= 1) return [];
      let nextPage = 2;
      let failed = false;
      const pages = [];
      async function worker() {
        while (!failed) {
          const page = nextPage;
          nextPage += 1;
          if (page > pageCount) return;
          try {
            pages.push(await fetchGuardPage(creator, page));
          } catch (error) {
            failed = true;
            throw error;
          }
        }
      }
      const workerCount = Math.min(2, pageCount - 1);
      await Promise.all(Array.from({length: workerCount}, () => worker()));
      return pages.sort((left, right) => left.pageNumber - right.pageNumber);
    }

    async function fetchDetails(uid) {
      const creator = await api.resolveRoom(uid);
      const [firstPage, ipLocation, streamRevenue] = await Promise.all([
        fetchGuardPage(creator, 1),
        fetchIpLocation(creator.uid),
        fetchStreamRevenue(creator.uid),
      ]);
      const summary = await writeSummary(creator, firstPage, ipLocation, streamRevenue);
      if (firstPage.pageCount > 500) throw createError('details_too_large');
      const remainingPages = await fetchRemainingPages(creator, firstPage.pageCount);
      const merged = mergeGuardPages(firstPage, remainingPages);
      const details = {
        creator,
        total: merged.total,
        members: merged.members,
        fetchedAt: now(),
      };
      await sessionCache.write(`details:${uid}`, details, DETAILS_TTL_MS);
      return {
        summary: {...summary, cacheState: 'network'},
        details: {...details, cacheState: 'network'},
      };
    }

    async function getDetails(context, {force = false} = {}) {
      const uid = await identityUid(context);
      const key = `details:${uid}`;
      const cached = await sessionCache.read(key);
      if (!force && cached.state === 'fresh') {
        return {details: {...cached.value, cacheState: 'fresh'}};
      }

      try {
        return await coalesce(inFlight, `details-network:${uid}`, async () => {
          if (!force) {
            const shared = await sessionCache.read(key);
            if (shared.state === 'fresh') {
              return {details: {...shared.value, cacheState: 'fresh'}};
            }
          }
          return fetchDetails(uid);
        });
      } catch (error) {
        if (cached.state === 'stale') {
          return {details: {...cached.value, cacheState: 'stale'}};
        }
        throw error;
      }
    }

    async function checkRefreshCooldown(uid) {
      const value = (await storageArea.get(`lastNetwork:${uid}`))?.[`lastNetwork:${uid}`];
      if (!Number.isSafeInteger(value)) return;
      const elapsed = now() - value;
      if (elapsed >= REFRESH_COOLDOWN_MS) return;
      throw createError('cooldown', {
        retryAfterMs: Math.max(1, REFRESH_COOLDOWN_MS - Math.max(0, elapsed)),
      });
    }

    async function refresh(request) {
      const uid = request.context.kind === 'space'
        ? request.context.uid
        : await identityUid(request.context);
      await checkRefreshCooldown(uid);
      if (!request.detailsOpen) {
        return {summary: await getSummary(request.context, {force: true})};
      }
      const result = await getDetails(request.context, {force: true});
      if (!result.summary) {
        const cachedSummary = await sessionCache.read(`summary:${uid}`);
        if (cachedSummary.state !== 'missing') {
          result.summary = {...cachedSummary.value, cacheState: cachedSummary.state};
        }
      }
      return result;
    }

    async function handle(message) {
      const request = normalizeRequest(message);
      let payload;
      if (request.type === 'guard.summary.get') {
        payload = {summary: await getSummary(request.context, {force: request.force})};
      } else if (request.type === 'guard.details.get') {
        payload = await getDetails(request.context, {force: request.force});
      } else if (request.type === 'guard.refresh') {
        payload = await refresh(request);
      } else if (request.type === 'guard.stream-revenue.retry') {
        payload = await retryVerifiedStreamRevenue(request.context);
      } else {
        throw createError('invalid_identity');
      }
      return {
        ok: true,
        requestId: request.requestId,
        pageGeneration: request.pageGeneration,
        ...payload,
      };
    }

    return Object.freeze({handle});
  }

  runtime.broker = Object.freeze({createGuardBroker});
})();
