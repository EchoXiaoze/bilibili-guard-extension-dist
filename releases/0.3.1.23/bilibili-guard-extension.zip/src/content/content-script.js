(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts || !runtime.pageContext) {
    throw new Error('Bilibili guard content dependencies are not initialized');
  }

  const {
    createError,
    ERROR_CODES,
    normalizeHttpsUrl,
    normalizePositiveInteger,
    normalizeUid,
    parsePageUrl,
  } = runtime.contracts;
  const CACHE_STATES = new Set(['network', 'fresh', 'stale']);
  const IP_LOCATION_STATUSES = new Set([
    'no_location',
    'auth_required',
    'risk_control',
    'unavailable',
  ]);
  const STREAM_REVENUE_STATUSES = new Set(['no_data', 'unavailable', 'verification_required']);

  function boundedText(value, maximum, fallback) {
    if (typeof value !== 'string') return fallback;
    const text = value.trim();
    return text ? text.slice(0, maximum) : fallback;
  }

  function normalizeCreator(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw createError('guard_lookup_failed');
    }
    const uid = normalizeUid(value.uid);
    const roomId = normalizeUid(value.roomId);
    if (!uid || !roomId) throw createError('guard_lookup_failed');
    return {
      uid,
      roomId,
      name: boundedText(value.name, 120, `UID ${uid}`),
      avatar: normalizeHttpsUrl(value.avatar),
    };
  }

  function normalizeCacheState(value) {
    if (!CACHE_STATES.has(value)) throw createError('guard_lookup_failed');
    return value;
  }

  function normalizeIpLocation(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return {status: 'unavailable', location: ''};
    }
    if (value.status === 'found') {
      const location = boundedText(value.location, 60, '');
      if (!location) return {status: 'unavailable', location: ''};
      const result = {status: 'found', location};
      if (value.source === 'space_tag' || value.source === 'space_tag_bottom') {
        result.source = value.source;
      }
      return result;
    }
    if (IP_LOCATION_STATUSES.has(value.status)) {
      return {status: value.status, location: ''};
    }
    return {status: 'unavailable', location: ''};
  }

  function normalizeStreamRevenue(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return {status: 'unavailable', total: null};
    }
    if (value.status === 'found') {
      const total = value.total;
      if (typeof total === 'number' && Number.isFinite(total) && total >= 0 && total <= 100_000_000) {
        return {status: 'found', total};
      }
      return {status: 'unavailable', total: null};
    }
    if (STREAM_REVENUE_STATUSES.has(value.status)) {
      return {status: value.status, total: null};
    }
    return {status: 'unavailable', total: null};
  }

  function normalizeSummary(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw createError('guard_lookup_failed');
    }
    const total = normalizePositiveInteger(value.total, {allowZero: true});
    const pageCount = normalizePositiveInteger(value.pageCount, {allowZero: true});
    const fetchedAt = normalizePositiveInteger(value.fetchedAt, {allowZero: true});
    if (total === null || pageCount === null || fetchedAt === null) {
      throw createError('guard_lookup_failed');
    }
    return {
      creator: normalizeCreator(value.creator),
      total,
      pageCount,
      fetchedAt,
      cacheState: normalizeCacheState(value.cacheState),
      ipLocation: normalizeIpLocation(value.ipLocation),
      streamRevenue: normalizeStreamRevenue(value.streamRevenue),
    };
  }

  function optionalInteger(value, {positive = false} = {}) {
    if (value === null || value === undefined) return null;
    return normalizePositiveInteger(value, {allowZero: !positive});
  }

  function normalizeMember(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const uid = normalizeUid(value.uid);
    const rank = optionalInteger(value.rank, {positive: true});
    const guardLevel = optionalInteger(value.guardLevel);
    const guardSubLevel = optionalInteger(value.guardSubLevel);
    const medalLevel = optionalInteger(value.medalLevel);
    if (
      !uid
      || (value.rank !== null && value.rank !== undefined && rank === null)
      || guardLevel === null
      || guardSubLevel === null
      || medalLevel === null
    ) return null;
    return {
      uid,
      nickname: boundedText(value.nickname, 120, `UID ${uid}`),
      avatar: normalizeHttpsUrl(value.avatar),
      rank,
      guardLevel,
      guardSubLevel,
      medalName: boundedText(value.medalName, 60, ''),
      medalLevel,
    };
  }

  function normalizeDetails(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || !Array.isArray(value.members)) {
      throw createError('guard_lookup_failed');
    }
    const total = normalizePositiveInteger(value.total, {allowZero: true});
    const fetchedAt = normalizePositiveInteger(value.fetchedAt, {allowZero: true});
    const members = value.members.map(normalizeMember).filter(Boolean);
    if (total === null || fetchedAt === null || members.length !== total) {
      throw createError('details_incomplete');
    }
    return {
      creator: normalizeCreator(value.creator),
      total,
      members,
      fetchedAt,
      cacheState: normalizeCacheState(value.cacheState),
    };
  }

  function createController({
    location,
    addEventListener,
    removeEventListener,
    setInterval,
    clearInterval,
    sendMessage,
    createPanel,
    randomId,
    getUpdateStatus = async () => null,
    subscribeUpdateStatus = () => () => {},
    initialUiState = {version: 1, left: null, top: null, minimized: false},
    saveUiState = async () => true,
    lookupAnchorSign = null,
    openRevenueVerification = null,
  }) {
    if (
      !location
      || typeof sendMessage !== 'function'
      || typeof createPanel !== 'function'
      || typeof randomId !== 'function'
      || typeof subscribeUpdateStatus !== 'function'
    ) {
      throw new TypeError('Content controller dependencies are invalid');
    }

    let currentContext = null;
    let currentKey = null;
    let currentCreatorUid = null;
    let generation = 0;
    let panel = null;
    let stopWatching = null;
    let started = false;
    let destroyed = false;
    let detailsOpen = false;
    let uiState = {...initialUiState};
    let autoDetailsPendingGeneration = null;
    let updateStatusRequested = false;
    let stopWatchingUpdateStatus = null;
    let anchorSignRequestSerial = 0;

    function renderUpdateStatus(response) {
      if (destroyed || !panel || response?.ok !== true) return;
      if (response.update?.available === true) panel.renderUpdate?.(response.update);
      else panel.clearUpdate?.();
    }

    function activeContext() {
      if (!currentCreatorUid) return currentContext;
      return {
        kind: 'space',
        uid: currentCreatorUid,
        key: `space:${currentCreatorUid}`,
      };
    }

    function renderFailure(error, expectedGeneration) {
      if (destroyed || expectedGeneration !== generation || !panel) return;
      const code = ERROR_CODES.has(error?.code) ? error.code : 'guard_lookup_failed';
      if (code === 'cooldown') {
        const retryAfterMs = normalizePositiveInteger(error?.retryAfterMs) ?? 1000;
        panel.renderCooldown(retryAfterMs);
        return;
      }
      panel.renderError(code);
    }

    async function request(type) {
      if (!currentContext || !panel || destroyed) return null;
      const expectedGeneration = generation;
      const requestId = randomId();
      const message = {
        type,
        requestId,
        pageGeneration: expectedGeneration,
        context: type === 'guard.summary.get' ? currentContext : activeContext(),
        force: type === 'guard.refresh' || type === 'guard.stream-revenue.retry',
      };
      if (type === 'guard.refresh') message.detailsOpen = detailsOpen;

      let response;
      try {
        response = await sendMessage(message);
      } catch {
        renderFailure({code: 'guard_lookup_failed'}, expectedGeneration);
        return null;
      }
      if (
        destroyed
        || expectedGeneration !== generation
        || !panel
        || !response
        || response.requestId !== requestId
        || response.pageGeneration !== expectedGeneration
      ) {
        return null;
      }
      if (response.ok !== true) {
        renderFailure(response.error, expectedGeneration);
        return response;
      }

      try {
        if (response.summary) {
          const summary = normalizeSummary(response.summary);
          currentCreatorUid = summary.creator.uid;
          panel.renderSummary(summary);
          if (autoDetailsPendingGeneration === expectedGeneration) {
            autoDetailsPendingGeneration = null;
            if (response.details === undefined) {
              panel.renderLoading();
              void request('guard.details.get');
            }
          }
        }
        if (response.details) {
          const details = normalizeDetails(response.details);
          currentCreatorUid = details.creator.uid;
          panel.renderDetails(details);
        }
        if (response.streamRevenue) {
          panel.renderStreamRevenue?.(normalizeStreamRevenue(response.streamRevenue));
        }
      } catch (error) {
        renderFailure(error, expectedGeneration);
      }
      return response;
    }

    async function onDetails() {
      detailsOpen = true;
      panel?.renderLoading();
      return request('guard.details.get');
    }

    async function onRefresh() {
      panel?.renderLoading();
      return request('guard.refresh');
    }

    async function onAnchorSign() {
      if (!currentCreatorUid || typeof lookupAnchorSign !== 'function') {
        panel?.renderAnchorSignError?.('unavailable');
        return null;
      }
      const expectedGeneration = generation;
      const serial = ++anchorSignRequestSerial;
      const uid = currentCreatorUid;
      panel?.renderAnchorSignLoading?.();
      try {
        const result = await lookupAnchorSign(uid);
        if (destroyed || generation !== expectedGeneration || serial !== anchorSignRequestSerial) return null;
        panel?.renderAnchorSignResult?.(result);
        return result;
      } catch (error) {
        if (destroyed || generation !== expectedGeneration || serial !== anchorSignRequestSerial) return null;
        const code = ['access_code_required', 'access_code_invalid', 'rate_limited'].includes(error?.code)
          ? error.code
          : 'unavailable';
        panel?.renderAnchorSignError?.(code);
        return null;
      }
    }

    function streamRevenueVerificationUrl(uid) {
      return new URL(`/liver/${encodeURIComponent(uid)}`, 'https://vtb.cat').href;
    }

    function onRevenueVerificationOpen() {
      if (!currentCreatorUid || typeof openRevenueVerification !== 'function') return false;
      try {
        openRevenueVerification(streamRevenueVerificationUrl(currentCreatorUid));
        return true;
      } catch {
        return false;
      }
    }

    async function onRevenueVerificationRetry() {
      if (!currentCreatorUid || !panel) return null;
      panel.renderRevenueVerificationLoading?.();
      return request('guard.stream-revenue.retry');
    }

    async function persistUiState(patch) {
      uiState = {...uiState, ...patch, version: 1};
      const saved = await saveUiState(uiState);
      if (!saved && !destroyed) panel?.renderSettingsError();
      return saved;
    }

    function onMinimize(position) {
      return persistUiState({...position, minimized: true});
    }

    function onPositionChange(position) {
      return persistUiState(position);
    }

    function onShow(position) {
      if (!uiState.minimized) return null;
      const persistence = persistUiState({...position, minimized: false});
      detailsOpen = true;
      if (currentCreatorUid) {
        panel?.renderLoading();
        return request('guard.details.get');
      }
      autoDetailsPendingGeneration = generation;
      return persistence;
    }

    function ensurePanel() {
      if (panel) return;
      panel = createPanel({
        initialState: uiState,
        onDetails,
        onRefresh,
        onMinimize,
        onShow,
        onPositionChange,
        onAnchorSign: typeof lookupAnchorSign === 'function' ? onAnchorSign : null,
        onRevenueVerificationOpen: typeof openRevenueVerification === 'function'
          ? onRevenueVerificationOpen
          : null,
        onRevenueVerificationRetry: typeof openRevenueVerification === 'function'
          ? onRevenueVerificationRetry
          : null,
      });
      if (!updateStatusRequested) {
        updateStatusRequested = true;
        Promise.resolve(getUpdateStatus()).then(renderUpdateStatus).catch(() => {});
      }
    }

    function navigate(href) {
      if (destroyed) return;
      const context = parsePageUrl(href);
      const nextKey = context?.key ?? null;
      if (nextKey === currentKey) return;
      autoDetailsPendingGeneration = null;
      anchorSignRequestSerial += 1;
      generation += 1;
      currentContext = context;
      currentKey = nextKey;
      currentCreatorUid = null;
      detailsOpen = false;

      if (!context) {
        panel?.destroy();
        panel = null;
        return;
      }
      ensurePanel();
      panel.renderNavigationLoading();
      void request('guard.summary.get');
    }

    function start() {
      if (started || destroyed) return;
      started = true;
      stopWatchingUpdateStatus = subscribeUpdateStatus(renderUpdateStatus);
      stopWatching = runtime.pageContext.watchLocation({
        location,
        addEventListener,
        removeEventListener,
        setInterval,
        clearInterval,
        onChange: navigate,
      });
      navigate(location.href);
    }

    function destroy() {
      if (destroyed) return;
      destroyed = true;
      autoDetailsPendingGeneration = null;
      anchorSignRequestSerial += 1;
      generation += 1;
      stopWatching?.();
      stopWatching = null;
      stopWatchingUpdateStatus?.();
      stopWatchingUpdateStatus = null;
      panel?.destroy();
      panel = null;
    }

    return Object.freeze({start, destroy});
  }

  async function bootstrap({storageArea, controllerOptions}) {
    const store = runtime.panelState.createStore({storageArea});
    const initialUiState = await store.load();
    const controller = createController({
      ...controllerOptions,
      initialUiState,
      saveUiState: state => store.save(state),
    });
    controller.start();
    return controller;
  }

  runtime.content = Object.freeze({
    bootstrap,
    createController,
    normalizeIpLocation,
    normalizeSummary,
    normalizeDetails,
  });

  if (globalThis.chrome?.runtime?.sendMessage && globalThis.document && runtime.panelView) {
    void bootstrap({
      storageArea: globalThis.chrome.storage.local,
      controllerOptions: {
        location: globalThis.location,
        addEventListener: globalThis.addEventListener.bind(globalThis),
        removeEventListener: globalThis.removeEventListener.bind(globalThis),
        setInterval: globalThis.setInterval.bind(globalThis),
        clearInterval: globalThis.clearInterval.bind(globalThis),
        sendMessage: message => globalThis.chrome.runtime.sendMessage(message),
        createPanel: options => runtime.panelView.createPanel({
          document: globalThis.document,
          getURL: path => globalThis.chrome.runtime.getURL(path),
          ...options,
        }),
        randomId: () => globalThis.crypto.randomUUID(),
        openRevenueVerification: url => {
          globalThis.open(url, '_blank', 'noopener,noreferrer');
        },
        getUpdateStatus: () => globalThis.chrome.runtime.sendMessage({type: 'update.status.get'}),
        subscribeUpdateStatus: listener => {
          const onChanged = (changes, areaName) => {
            const state = changes?.bilibiliGuardUpdateState?.newValue;
            if (areaName === 'local' && state) listener({ok: true, update: state});
          };
          globalThis.chrome.storage.onChanged.addListener(onChanged);
          return () => globalThis.chrome.storage.onChanged.removeListener(onChanged);
        },
      },
    }).catch(() => {});
  }
})();
