(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts) throw new Error('Bilibili guard contracts are not initialized');

  const {
    createError,
    normalizeBvid,
    normalizeHttpsUrl,
    normalizePositiveInteger,
    normalizeUid,
  } = runtime.contracts;
  const ENDPOINTS = Object.freeze({
    view: 'https://api.bilibili.com/x/web-interface/view',
    room: 'https://api.live.bilibili.com/room/v1/Room/get_status_info_by_uids',
    guard: 'https://api.live.bilibili.com/xlive/app-room/v2/guardTab/topList',
    ipLocation: 'http://127.0.0.1:8787/api/bilibili/ip-location',
  });
  const MAX_BODY_BYTES = 2 * 1024 * 1024;
  const MAX_IP_LOCATION_BODY_BYTES = 16 * 1024;
  const IP_LOCATION_TIMEOUT_MS = 2500;
  const IP_LOCATION_STATUSES = new Set([
    'found',
    'no_location',
    'auth_required',
    'risk_control',
  ]);
  const IP_LOCATION_SOURCES = new Set(['space_tag', 'space_tag_bottom']);

  function displayName(value, uid) {
    if (typeof value !== 'string') return `UID ${uid}`;
    const text = value.trim();
    return text ? text.slice(0, 120) : `UID ${uid}`;
  }

  function retryDelay(response) {
    if (response.status !== 429) return 1000;
    const raw = response.headers?.get?.('Retry-After');
    if (typeof raw !== 'string' || !/^[1-5]$/u.test(raw.trim())) return 1000;
    return Number(raw.trim()) * 1000;
  }

  function createBilibiliApi({fetchImpl, sleep, timeoutMs = 8000}) {
    if (
      typeof fetchImpl !== 'function'
      || typeof sleep !== 'function'
      || !Number.isSafeInteger(timeoutMs)
      || timeoutMs <= 0
    ) {
      throw new TypeError('Bilibili API dependencies are invalid');
    }

    async function requestJson(url, failureCode) {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        try {
          const response = await fetchImpl(url.href, {
            method: 'GET',
            credentials: 'omit',
            redirect: 'error',
            cache: 'no-store',
            signal: controller.signal,
          });

          if (response.status === 429 || response.status >= 500) {
            if (attempt === 0) {
              await sleep(retryDelay(response));
              continue;
            }
            throw createError(failureCode);
          }
          if (!response.ok) throw createError(failureCode);

          const contentLength = response.headers?.get?.('content-length');
          if (contentLength !== null && contentLength !== undefined) {
            const size = Number(contentLength);
            if (!Number.isFinite(size) || size < 0 || size > MAX_BODY_BYTES) {
              throw createError(failureCode);
            }
          }
          const text = await response.text();
          if (typeof text !== 'string' || text.length > MAX_BODY_BYTES) {
            throw createError(failureCode);
          }
          let payload;
          try {
            payload = JSON.parse(text);
          } catch {
            throw createError(failureCode);
          }
          if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
            throw createError(failureCode);
          }
          if (payload.code === -352 || payload.code === -412) {
            throw createError('risk_controlled');
          }
          if (payload.code !== 0) throw createError(failureCode);
          return payload;
        } catch (error) {
          if (controller.signal.aborted) throw createError('request_timeout');
          if (error?.code) throw error;
          if (attempt === 0) {
            await sleep(1000);
            continue;
          }
          throw createError(failureCode);
        } finally {
          clearTimeout(timeout);
        }
      }
      throw createError(failureCode);
    }

    async function resolveVideo(bvidValue) {
      const bvid = normalizeBvid(bvidValue);
      if (!bvid) throw createError('creator_lookup_failed');
      const url = new URL(ENDPOINTS.view);
      url.searchParams.set('bvid', bvid);
      const payload = await requestJson(url, 'creator_lookup_failed');
      const owner = payload.data?.owner;
      const uid = normalizeUid(owner?.mid);
      if (!uid) throw createError('creator_lookup_failed');
      return {
        uid,
        name: displayName(owner.name, uid),
        avatar: normalizeHttpsUrl(owner.face),
      };
    }

    async function resolveRoom(uidValue) {
      const uid = normalizeUid(uidValue);
      if (!uid) throw createError('invalid_identity');
      const url = new URL(ENDPOINTS.room);
      url.searchParams.append('uids[]', uid);
      const payload = await requestJson(url, 'creator_lookup_failed');
      const room = payload.data?.[uid];
      const roomId = normalizeUid(room?.room_id);
      if (!room || !roomId) throw createError('no_live_room');
      return {
        uid,
        roomId,
        name: displayName(room.uname, uid),
        avatar: normalizeHttpsUrl(room.face),
      };
    }

    async function fetchGuardPage({roomId: roomValue, creatorUid: uidValue, page: pageValue}) {
      const roomId = normalizeUid(roomValue);
      const creatorUid = normalizeUid(uidValue);
      const page = normalizePositiveInteger(pageValue);
      if (!roomId || !creatorUid || !page) throw createError('invalid_identity');
      const url = new URL(ENDPOINTS.guard);
      url.searchParams.set('roomid', roomId);
      url.searchParams.set('ruid', creatorUid);
      url.searchParams.set('page', String(page));
      url.searchParams.set('page_size', '10');
      const payload = await requestJson(url, 'guard_lookup_failed');
      if (!payload.data || typeof payload.data !== 'object' || Array.isArray(payload.data)) {
        throw createError('guard_lookup_failed');
      }
      return payload.data;
    }

    async function fetchIpLocation(uidValue) {
      const unavailable = Object.freeze({status: 'unavailable', location: ''});
      const uid = normalizeUid(uidValue);
      if (!uid) return unavailable;
      const url = new URL(ENDPOINTS.ipLocation);
      url.searchParams.set('uid', uid);
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        Math.min(timeoutMs, IP_LOCATION_TIMEOUT_MS),
      );
      try {
        const response = await fetchImpl(url.href, {
          method: 'GET',
          credentials: 'omit',
          redirect: 'error',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (!response?.ok) return unavailable;
        const contentLength = response.headers?.get?.('content-length');
        if (contentLength !== null && contentLength !== undefined) {
          const size = Number(contentLength);
          if (!Number.isFinite(size) || size < 0 || size > MAX_IP_LOCATION_BODY_BYTES) {
            return unavailable;
          }
        }
        const text = await response.text();
        if (typeof text !== 'string' || text.length > MAX_IP_LOCATION_BODY_BYTES) {
          return unavailable;
        }
        let payload;
        try {
          payload = JSON.parse(text);
        } catch {
          return unavailable;
        }
        if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return unavailable;
        const status = IP_LOCATION_STATUSES.has(payload.status)
          ? payload.status
          : 'unavailable';
        if (status !== 'found') return Object.freeze({status, location: ''});
        if (typeof payload.location !== 'string') return unavailable;
        const location = payload.location.trim().slice(0, 60);
        if (!location) return unavailable;
        const result = {status, location};
        if (IP_LOCATION_SOURCES.has(payload.source)) result.source = payload.source;
        return Object.freeze(result);
      } catch {
        return unavailable;
      } finally {
        clearTimeout(timeout);
      }
    }

    return Object.freeze({resolveVideo, resolveRoom, fetchGuardPage, fetchIpLocation});
  }

  runtime.api = Object.freeze({ENDPOINTS, createBilibiliApi});
})();
