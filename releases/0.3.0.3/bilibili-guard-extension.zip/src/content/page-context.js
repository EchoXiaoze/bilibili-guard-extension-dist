(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime) throw new Error('Bilibili guard namespace is not initialized');

  function watchLocation({
    location,
    addEventListener,
    removeEventListener,
    setInterval,
    clearInterval,
    onChange,
  }) {
    if (!location || typeof onChange !== 'function') {
      throw new TypeError('Location watcher dependencies are invalid');
    }
    let lastHref = location.href;
    const check = () => {
      if (location.href === lastHref) return;
      lastHref = location.href;
      onChange(lastHref);
    };
    addEventListener('popstate', check);
    addEventListener('pageshow', check);
    const timer = setInterval(check, 500);
    let stopped = false;
    return () => {
      if (stopped) return;
      stopped = true;
      removeEventListener('popstate', check);
      removeEventListener('pageshow', check);
      clearInterval(timer);
    };
  }

  runtime.pageContext = Object.freeze({watchLocation});
})();
