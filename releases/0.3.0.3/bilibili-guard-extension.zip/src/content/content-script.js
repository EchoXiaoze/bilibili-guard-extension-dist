(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.contracts || !runtime.pageContext) {
    throw new Error('Bilibili guard content dependencies are not initialized');
  }

  const {
    createError,
    ERROR_CODES,
    normalizeHttpsUrl,
    normalizePositiveInteger,
    normalizeUid,
    parsePageUrl,
  } = runtime.contracts;
  const CACHE_STATES = new Set(['network', 'fresh', 'stale']);

  function boundedText(value, maximum, fallback) {
    if (typeof value !== 'string') return fallback;
    const text = value.trim();
    return text ? text.slice(0, maximum) : fallback;
  }

  function normalizeCreator(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw createError('guard_lookup_failed');
    }
    const uid = normalizeUid(value.uid);
    const roomId = normalizeUid(value.roomId);
    if (!uid || !roomId) throw createError('guard_lookup_failed');
    return {
      uid,
      roomId,
      name: boundedText(value.name, 120, `UID ${uid}`),
      avatar: normalizeHttpsUrl(value.avatar),
    };
  }

  function normalizeCacheState(value) {
    if (!CACHE_STATES.has(value)) throw createError('guard_lookup_failed');
    return value;
  }

  function normalizeSummary(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw createError('guard_lookup_failed');
    }
    const total = normalizePositiveInteger(value.total, {allowZero: true});
    const pageCount = normalizePositiveInteger(value.pageCount, {allowZero: true});
    const fetchedAt = normalizePositiveInteger(value.fetchedAt, {allowZero: true});
    if (total === null || pageCount === null || fetchedAt === null) {
      throw createError('guard_lookup_failed');
    }
    return {
      creator: normalizeCreator(value.creator),
      total,
      pageCount,
      fetchedAt,
      cacheState: normalizeCacheState(value.cacheState),
    };
  }

  function optionalInteger(value, {positive = false} = {}) {
    if (value === null || value === undefined) return null;
    return normalizePositiveInteger(value, {allowZero: !positive});
  }

  function normalizeMember(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const uid = normalizeUid(value.uid);
    const rank = optionalInteger(value.rank, {positive: true});
    const guardLevel = optionalInteger(value.guardLevel);
    const guardSubLevel = optionalInteger(value.guardSubLevel);
    const medalLevel = optionalInteger(value.medalLevel);
    if (
      !uid
      || (value.rank !== null && value.rank !== undefined && rank === null)
      || guardLevel === null
      || guardSubLevel === null
      || medalLevel === null
    ) return null;
    return {
      uid,
      nickname: boundedText(value.nickname, 120, `UID ${uid}`),
      avatar: normalizeHttpsUrl(value.avatar),
      rank,
      guardLevel,
      guardSubLevel,
      medalName: boundedText(value.medalName, 60, ''),
      medalLevel,
    };
  }

  function normalizeDetails(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || !Array.isArray(value.members)) {
      throw createError('guard_lookup_failed');
    }
    const total = normalizePositiveInteger(value.total, {allowZero: true});
    const fetchedAt = normalizePositiveInteger(value.fetchedAt, {allowZero: true});
    const members = value.members.map(normalizeMember).filter(Boolean);
    if (total === null || fetchedAt === null || members.length !== total) {
      throw createError('details_incomplete');
    }
    return {
      creator: normalizeCreator(value.creator),
      total,
      members,
      fetchedAt,
      cacheState: normalizeCacheState(value.cacheState),
    };
  }

  function createController({
    location,
    addEventListener,
    removeEventListener,
    setInterval,
    clearInterval,
    sendMessage,
    createPanel,
    randomId,
    getUpdateStatus = async () => null,
    subscribeUpdateStatus = () => () => {},
    initialUiState = {version: 1, left: null, top: null, minimized: false},
    saveUiState = async () => true,
  }) {
    if (
      !location
      || typeof sendMessage !== 'function'
      || typeof createPanel !== 'function'
      || typeof randomId !== 'function'
      || typeof subscribeUpdateStatus !== 'function'
    ) {
      throw new TypeError('Content controller dependencies are invalid');
    }

    let currentContext = null;
    let currentKey = null;
    let currentCreatorUid = null;
    let generation = 0;
    let panel = null;
    let stopWatching = null;
    let started = false;
    let destroyed = false;
    let detailsOpen = false;
    let uiState = {...initialUiState};
    let autoDetailsPendingGeneration = null;
    let updateStatusRequested = false;
    let stopWatchingUpdateStatus = null;

    function renderUpdateStatus(response) {
      if (destroyed || !panel || response?.ok !== true) return;
      if (response.update?.available === true) panel.renderUpdate?.(response.update);
      else panel.clearUpdate?.();
    }

    function activeContext() {
      if (!currentCreatorUid) return currentContext;
      return {
        kind: 'space',
        uid: currentCreatorUid,
        key: `space:${currentCreatorUid}`,
      };
    }

    function renderFailure(error, expectedGeneration) {
      if (destroyed || expectedGeneration !== generation || !panel) return;
      const code = ERROR_CODES.has(error?.code) ? error.code : 'guard_lookup_failed';
      if (code === 'cooldown') {
        const retryAfterMs = normalizePositiveInteger(error?.retryAfterMs) ?? 1000;
        panel.renderCooldown(retryAfterMs);
        return;
      }
      panel.renderError(code);
    }

    async function request(type) {
      if (!currentContext || !panel || destroyed) return null;
      const expectedGeneration = generation;
      const requestId = randomId();
      const message = {
        type,
        requestId,
        pageGeneration: expectedGeneration,
        context: type === 'guard.summary.get' ? currentContext : activeContext(),
        force: type === 'guard.refresh',
      };
      if (type === 'guard.refresh') message.detailsOpen = detailsOpen;

      let response;
      try {
        response = await sendMessage(message);
      } catch {
        renderFailure({code: 'guard_lookup_failed'}, expectedGeneration);
        return null;
      }
      if (
        destroyed
        || expectedGeneration !== generation
        || !panel
        || !response
        || response.requestId !== requestId
        || response.pageGeneration !== expectedGeneration
      ) {
        return null;
      }
      if (response.ok !== true) {
        renderFailure(response.error, expectedGeneration);
        return response;
      }

      try {
        if (response.summary) {
          const summary = normalizeSummary(response.summary);
          currentCreatorUid = summary.creator.uid;
          panel.renderSummary(summary);
          if (autoDetailsPendingGeneration === expectedGeneration) {
            autoDetailsPendingGeneration = null;
            if (response.details === undefined) {
              panel.renderLoading();
              void request('guard.details.get');
            }
          }
        }
        if (response.details) {
          const details = normalizeDetails(response.details);
          currentCreatorUid = details.creator.uid;
          panel.renderDetails(details);
        }
      } catch (error) {
        renderFailure(error, expectedGeneration);
      }
      return response;
    }

    async function onDetails() {
      detailsOpen = true;
      panel?.renderLoading();
      return request('guard.details.get');
    }

    async function onRefresh() {
      panel?.renderLoading();
      return request('guard.refresh');
    }

    async function persistUiState(patch) {
      uiState = {...uiState, ...patch, version: 1};
      const saved = await saveUiState(uiState);
      if (!saved && !destroyed) panel?.renderSettingsError();
      return saved;
    }

    function onMinimize(position) {
      return persistUiState({...position, minimized: true});
    }

    function onPositionChange(position) {
      return persistUiState(position);
    }

    function onShow(position) {
      if (!uiState.minimized) return null;
      const persistence = persistUiState({...position, minimized: false});
      detailsOpen = true;
      if (currentCreatorUid) {
        panel?.renderLoading();
        return request('guard.details.get');
      }
      autoDetailsPendingGeneration = generation;
      return persistence;
    }

    function ensurePanel() {
      if (panel) return;
      panel = createPanel({
        initialState: uiState,
        onDetails,
        onRefresh,
        onMinimize,
        onShow,
        onPositionChange,
      });
      if (!updateStatusRequested) {
        updateStatusRequested = true;
        Promise.resolve(getUpdateStatus()).then(renderUpdateStatus).catch(() => {});
      }
    }

    function navigate(href) {
      if (destroyed) return;
      const context = parsePageUrl(href);
      const nextKey = context?.key ?? null;
      if (nextKey === currentKey) return;
      autoDetailsPendingGeneration = null;
      generation += 1;
      currentContext = context;
      currentKey = nextKey;
      currentCreatorUid = null;
      detailsOpen = false;

      if (!context) {
        panel?.destroy();
        panel = null;
        return;
      }
      ensurePanel();
      panel.renderNavigationLoading();
      void request('guard.summary.get');
    }

    function start() {
      if (started || destroyed) return;
      started = true;
      stopWatchingUpdateStatus = subscribeUpdateStatus(renderUpdateStatus);
      stopWatching = runtime.pageContext.watchLocation({
        location,
        addEventListener,
        removeEventListener,
        setInterval,
        clearInterval,
        onChange: navigate,
      });
      navigate(location.href);
    }

    function destroy() {
      if (destroyed) return;
      destroyed = true;
      autoDetailsPendingGeneration = null;
      generation += 1;
      stopWatching?.();
      stopWatching = null;
      stopWatchingUpdateStatus?.();
      stopWatchingUpdateStatus = null;
      panel?.destroy();
      panel = null;
    }

    return Object.freeze({start, destroy});
  }

  async function bootstrap({storageArea, controllerOptions}) {
    const store = runtime.panelState.createStore({storageArea});
    const initialUiState = await store.load();
    const controller = createController({
      ...controllerOptions,
      initialUiState,
      saveUiState: state => store.save(state),
    });
    controller.start();
    return controller;
  }

  runtime.content = Object.freeze({
    bootstrap,
    createController,
    normalizeSummary,
    normalizeDetails,
  });

  if (globalThis.chrome?.runtime?.sendMessage && globalThis.document && runtime.panelView) {
    void bootstrap({
      storageArea: globalThis.chrome.storage.local,
      controllerOptions: {
        location: globalThis.location,
        addEventListener: globalThis.addEventListener.bind(globalThis),
        removeEventListener: globalThis.removeEventListener.bind(globalThis),
        setInterval: globalThis.setInterval.bind(globalThis),
        clearInterval: globalThis.clearInterval.bind(globalThis),
        sendMessage: message => globalThis.chrome.runtime.sendMessage(message),
        createPanel: options => runtime.panelView.createPanel({
          document: globalThis.document,
          getURL: path => globalThis.chrome.runtime.getURL(path),
          ...options,
        }),
        randomId: () => globalThis.crypto.randomUUID(),
        getUpdateStatus: () => globalThis.chrome.runtime.sendMessage({type: 'update.status.get'}),
        subscribeUpdateStatus: listener => {
          const onChanged = (changes, areaName) => {
            const state = changes?.bilibiliGuardUpdateState?.newValue;
            if (areaName === 'local' && state) listener({ok: true, update: state});
          };
          globalThis.chrome.storage.onChanged.addListener(onChanged);
          return () => globalThis.chrome.storage.onChanged.removeListener(onChanged);
        },
      },
    }).catch(() => {});
  }
})();
