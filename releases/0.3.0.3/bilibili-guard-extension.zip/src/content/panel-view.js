(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime?.panelStyle || !runtime?.panelState || !runtime.guardData) {
    throw new Error('Bilibili guard panel dependencies are not initialized');
  }

  const {guardTier} = runtime.guardData;
  const ERROR_TEXT = Object.freeze({
    unsupported_page: '当前页面不受支持。',
    invalid_identity: '无法识别当前创作者。',
    creator_lookup_failed: '读取创作者信息失败，请稍后重试。',
    no_live_room: '该创作者没有可用的直播间。',
    guard_lookup_failed: '读取大航海数据失败，请稍后重试。',
    risk_controlled: 'B站接口访问受限，请稍后再试。',
    request_timeout: '请求超时，请检查网络后重试。',
    details_incomplete: '名单数据不完整，未展示部分结果。',
    details_too_large: '名单规模超过安全上限。',
  });

  function textElement(document, tag, className, text) {
    const element = document.createElement(tag);
    element.className = className;
    element.textContent = String(text ?? '');
    return element;
  }

  function profileLink(document, uid, className, text) {
    const link = textElement(document, 'a', className, text);
    link.href = `https://space.bilibili.com/${uid}`;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    return link;
  }

  function createPanel({
    document,
    viewport = globalThis,
    getURL,
    initialState,
    onDetails,
    onRefresh,
    onMinimize,
    onShow,
    onPositionChange,
  }) {
    if (!document?.createElement || !viewport || typeof getURL !== 'function') {
      throw new TypeError('Panel dependencies are invalid');
    }
    const host = document.createElement('div');
    host.id = 'bilibili-guard-extension-host';
    const root = host.attachShadow({mode: 'open'});

    const style = document.createElement('style');
    style.textContent = runtime.panelStyle.css;
    const section = document.createElement('section');
    section.className = 'guard-panel';
    section.setAttribute('role', 'region');
    section.setAttribute('aria-label', 'B站大航海详情');

    const header = document.createElement('header');
    header.className = 'guard-header';
    const headingGroup = document.createElement('div');
    const heading = textElement(document, 'h2', 'guard-heading', '大航海');
    const creator = document.createElement('div');
    creator.className = 'guard-creator';
    const creatorName = profileLink(document, '1', 'guard-creator-name', '正在识别创作者');
    creatorName.removeAttribute('href');
    const creatorUid = textElement(document, 'span', 'guard-creator-uid', ' · UID --');
    creator.append(creatorName, creatorUid);
    headingGroup.append(heading, creator);

    const countWrap = document.createElement('div');
    countWrap.className = 'guard-count-wrap';
    const count = textElement(document, 'div', 'guard-count', '--');
    const countLabel = textElement(document, 'span', 'guard-count-label', '大航海');
    countWrap.append(count, countLabel);
    const toggle = textElement(document, 'button', 'guard-toggle', '最小化');
    toggle.type = 'button';
    header.append(headingGroup, countWrap, toggle);

    const status = textElement(document, 'div', 'guard-status', '等待页面识别');
    status.setAttribute('aria-live', 'polite');
    const update = document.createElement('div');
    update.className = 'guard-update';
    update.hidden = true;
    const updateLink = textElement(document, 'a', 'guard-update-link', '');
    updateLink.target = '_blank';
    updateLink.rel = 'noopener noreferrer';
    update.append(updateLink);
    const actions = document.createElement('div');
    actions.className = 'guard-actions';
    const detailsButton = textElement(document, 'button', 'guard-button', '查看详情');
    detailsButton.type = 'button';
    detailsButton.setAttribute('aria-label', '查看大航海详情');
    const refreshButton = textElement(document, 'button', 'guard-button is-secondary', '刷新');
    refreshButton.type = 'button';
    refreshButton.setAttribute('aria-label', '刷新大航海数据');
    detailsButton.addEventListener('click', () => onDetails?.());
    refreshButton.addEventListener('click', () => onRefresh?.());
    actions.append(detailsButton, refreshButton);
    const list = document.createElement('div');
    list.className = 'guard-list';
    list.setAttribute('aria-label', '大航海成员列表');

    section.append(header, status, update, actions, list);
    root.append(style, section);
    (document.documentElement ?? document.body).append(host);

    let destroyed = false;
    let activeDrag = null;

    function geometry() {
      const panelBox = section.getBoundingClientRect();
      const headerBox = header.getBoundingClientRect();
      return {
        viewportWidth: viewport.innerWidth,
        viewportHeight: viewport.innerHeight,
        panelWidth: panelBox.width,
        panelHeight: panelBox.height,
        headerHeight: headerBox.height,
      };
    }

    const normalizedInitialState = runtime.panelState.normalizeStoredState(initialState);
    setMinimized(normalizedInitialState.minimized);
    const resolvedState = runtime.panelState.resolveState(normalizedInitialState, geometry());
    let position = {left: resolvedState.left, top: resolvedState.top};

    function applyPosition(next) {
      position = {left: next.left, top: next.top};
      host.style.left = `${position.left}px`;
      host.style.top = `${position.top}px`;
      host.style.right = 'auto';
    }

    function currentPosition() {
      return {left: position.left, top: position.top};
    }

    function clampPosition() {
      return runtime.panelState.clampPosition(position, geometry());
    }

    function clampPositionAndNotify() {
      const next = clampPosition();
      if (next.left === position.left && next.top === position.top) return false;
      applyPosition(next);
      onPositionChange?.(currentPosition());
      return true;
    }

    function setMinimized(minimized) {
      host.classList.toggle('is-minimized', minimized);
      toggle.textContent = minimized ? '显示' : '最小化';
      toggle.setAttribute('aria-label', minimized ? '显示大航海详情' : '最小化大航海详情');
      toggle.setAttribute('aria-pressed', String(minimized));
    }

    function isInteractiveHeaderTarget(target) {
      for (let node = target; node && node !== header; node = node.parentNode) {
        if (
          ['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA'].includes(node.tagName)
          || node.getAttribute?.('role') === 'button'
        ) return true;
      }
      return false;
    }

    function finishDrag(pointerId) {
      if (!activeDrag || activeDrag.pointerId !== pointerId) return;
      header.releasePointerCapture(pointerId);
      activeDrag = null;
      onPositionChange?.(currentPosition());
    }

    function onPointerDown(event) {
      if (
        destroyed
        || event.button !== 0
        || event.isPrimary !== true
        || isInteractiveHeaderTarget(event.target)
      ) return;
      activeDrag = {
        pointerId: event.pointerId,
        clientX: event.clientX,
        clientY: event.clientY,
        position: currentPosition(),
      };
      header.setPointerCapture(event.pointerId);
      event.preventDefault();
    }

    function onPointerMove(event) {
      if (!activeDrag || activeDrag.pointerId !== event.pointerId) return;
      applyPosition(runtime.panelState.clampPosition({
        left: activeDrag.position.left + (event.clientX - activeDrag.clientX),
        top: activeDrag.position.top + (event.clientY - activeDrag.clientY),
      }, geometry()));
      event.preventDefault();
    }

    function onPointerUp(event) {
      finishDrag(event.pointerId);
    }

    function onPointerCancel(event) {
      finishDrag(event.pointerId);
    }

    function onResize() {
      if (destroyed) return;
      clampPositionAndNotify();
    }

    header.addEventListener('pointerdown', onPointerDown);
    header.addEventListener('pointermove', onPointerMove);
    header.addEventListener('pointerup', onPointerUp);
    header.addEventListener('pointercancel', onPointerCancel);
    viewport.addEventListener('resize', onResize);
    applyPosition(position);

    toggle.addEventListener('click', () => {
      if (destroyed) return;
      const minimized = !host.classList.contains('is-minimized');
      setMinimized(minimized);
      const next = clampPosition();
      if (next.left !== position.left || next.top !== position.top) applyPosition(next);
      if (minimized) onMinimize?.(currentPosition());
      else onShow?.(currentPosition());
    });

    function setBusy(busy) {
      detailsButton.disabled = busy;
      refreshButton.disabled = busy;
    }

    function setStatus(text, state = '') {
      status.className = state ? `guard-status is-${state}` : 'guard-status';
      status.textContent = text;
    }

    function renderCreator(value) {
      creatorName.textContent = value.name;
      creatorName.href = `https://space.bilibili.com/${value.uid}`;
      creatorUid.textContent = ` · UID ${value.uid}`;
    }

    function resetCreator() {
      creatorName.textContent = '正在识别创作者';
      creatorName.removeAttribute('href');
      creatorUid.textContent = ' · UID --';
      count.textContent = '--';
      list.replaceChildren();
    }

    function renderLoading() {
      if (destroyed) return;
      setBusy(true);
      setStatus('正在读取大航海数据…');
      clampPositionAndNotify();
    }

    function renderNavigationLoading() {
      if (destroyed) return;
      resetCreator();
      renderLoading();
    }

    function renderSummary(summary) {
      if (destroyed) return;
      renderCreator(summary.creator);
      count.textContent = String(summary.total);
      list.replaceChildren();
      setBusy(false);
      if (summary.cacheState === 'stale') setStatus('当前显示缓存数据，可稍后重试。', 'stale');
      else setStatus('概要已更新，点击“查看详情”加载完整名单。');
      clampPositionAndNotify();
    }

    function avatarStack(member, tier) {
      const shell = document.createElement('div');
      shell.className = member.avatar ? 'guard-avatar-shell' : 'guard-avatar-shell is-placeholder';
      const base = textElement(document, 'span', 'guard-avatar-base', '👤');
      shell.append(base);
      if (member.avatar) {
        const avatar = document.createElement('img');
        avatar.className = 'guard-avatar';
        avatar.src = member.avatar;
        avatar.alt = `${member.nickname}头像`;
        avatar.loading = 'lazy';
        avatar.referrerPolicy = 'no-referrer';
        avatar.addEventListener('error', () => {
          avatar.removeAttribute('src');
          shell.classList.add('is-placeholder');
        });
        shell.append(avatar);
      }
      if (tier.frame) {
        const frame = document.createElement('img');
        frame.className = 'guard-frame';
        frame.src = getURL(`assets/frames/${tier.frame}`);
        frame.alt = `${tier.name}官方头像框`;
        frame.addEventListener('error', () => frame.remove());
        shell.append(frame);
      }
      return shell;
    }

    function memberRow(member) {
      const tier = guardTier(member.guardLevel);
      const row = document.createElement('article');
      row.className = 'guard-member';
      const body = document.createElement('div');
      body.className = 'guard-member-body';
      const top = document.createElement('div');
      top.className = 'guard-member-top';
      const name = profileLink(document, member.uid, 'guard-member-name', member.nickname);
      const rank = textElement(
        document,
        'span',
        'guard-rank',
        member.rank === null ? '排名 --' : `#${member.rank}`,
      );
      top.append(name, rank);
      const meta = document.createElement('div');
      meta.className = 'guard-member-meta';
      const tierText = tier.frame ? tier.name : `${tier.name} ${member.guardLevel}`;
      const tierBadge = textElement(document, 'span', 'guard-tier', tierText);
      const uid = textElement(document, 'span', 'guard-member-uid', `UID ${member.uid}`);
      meta.append(tierBadge, uid);
      const medalText = member.medalName
        ? `${member.medalName} · Lv.${member.medalLevel}`
        : `未显示粉丝牌 · Lv.${member.medalLevel}`;
      const medal = textElement(document, 'div', 'guard-medal', medalText);
      body.append(top, meta, medal);
      row.append(avatarStack(member, tier), body);
      return row;
    }

    function renderDetails(details) {
      if (destroyed) return;
      renderCreator(details.creator);
      count.textContent = String(details.total);
      list.replaceChildren();
      if (details.members.length === 0) {
        list.append(textElement(document, 'div', 'guard-empty', '暂无大航海成员'));
      } else {
        list.append(...details.members.map(memberRow));
      }
      setBusy(false);
      if (details.cacheState === 'stale') setStatus('详情请求失败，当前显示缓存数据。', 'stale');
      else setStatus(`已加载 ${details.total} 名大航海成员。`);
      clampPositionAndNotify();
    }

    function renderError(code) {
      if (destroyed) return;
      setBusy(false);
      setStatus(ERROR_TEXT[code] ?? ERROR_TEXT.guard_lookup_failed, 'error');
      clampPositionAndNotify();
    }

    function renderCooldown(retryAfterMs) {
      if (destroyed) return;
      setBusy(false);
      const seconds = Math.max(1, Math.ceil(retryAfterMs / 1000));
      setStatus(`刷新过于频繁，请在 ${seconds} 秒后重试。`, 'cooldown');
      clampPositionAndNotify();
    }

    function renderSettingsError() {
      if (destroyed) return;
      setBusy(false);
      setStatus('面板设置暂时无法保存。', 'error');
      clampPositionAndNotify();
    }

    function clearUpdate() {
      update.hidden = true;
      updateLink.textContent = '';
      updateLink.removeAttribute('href');
    }

    function renderUpdate(value) {
      if (destroyed) return;
      const version = typeof value?.version === 'string' && /^(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*)){0,3}$/u.test(value.version)
        ? value.version
        : null;
      const expectedUrl = 'https://echoxiaoze.github.io/bilibili-guard-extension-dist/extension/bilibili-guard-extension.zip';
      if (!version || value?.extensionUrl !== expectedUrl) {
        clearUpdate();
        return;
      }
      updateLink.textContent = `发现新版本 ${version}，点击下载`;
      updateLink.href = expectedUrl;
      update.hidden = false;
      clampPositionAndNotify();
    }

    function destroy() {
      if (destroyed) return;
      destroyed = true;
      viewport.removeEventListener('resize', onResize);
      if (activeDrag) header.releasePointerCapture(activeDrag.pointerId);
      activeDrag = null;
      host.remove();
    }

    return Object.freeze({
      host,
      root,
      renderLoading,
      renderNavigationLoading,
      renderSummary,
      renderDetails,
      renderError,
      renderCooldown,
      renderSettingsError,
      renderUpdate,
      clearUpdate,
      destroy,
    });
  }

  runtime.panelView = Object.freeze({createPanel});
})();
