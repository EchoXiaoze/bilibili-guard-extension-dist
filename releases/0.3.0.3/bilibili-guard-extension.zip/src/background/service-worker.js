importScripts(
  '../shared/namespace.js',
  '../shared/contracts.js',
  '../shared/guard-data.js',
  '../shared/version.js',
  '../shared/update-manifest.js',
  './cache.js',
  './api.js',
  './broker.js',
  './updater.js',
);

const runtime = globalThis.__BILIBILI_GUARD__;
const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
const apiClient = runtime.api.createBilibiliApi({
  fetchImpl: fetch.bind(globalThis),
  sleep,
  timeoutMs: 8000,
});
const guardBroker = runtime.broker.createGuardBroker({
  api: apiClient,
  storageArea: chrome.storage.session,
  now: Date.now,
});
const updateChecker = runtime.updater.create({
  fetchImpl: fetch.bind(globalThis),
  storageArea: chrome.storage.local,
  alarms: chrome.alarms,
  currentVersion: chrome.runtime.getManifest().version,
  now: Date.now,
  timeoutMs: 8000,
});

void updateChecker.initialize();
chrome.runtime.onInstalled.addListener(() => { void updateChecker.check(); });
chrome.runtime.onStartup.addListener(() => { void updateChecker.check(); });
chrome.alarms.onAlarm.addListener(alarm => { void updateChecker.handleAlarm(alarm); });

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const operation = message?.type === 'update.status.get' || message?.type === 'update.check'
    ? updateChecker.handleMessage(message)
    : guardBroker.handle(message);
  operation.then(sendResponse, error => sendResponse(runtime.contracts.safeError(error, message)));
  return true;
});
