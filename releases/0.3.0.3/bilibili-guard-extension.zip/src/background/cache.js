(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime) throw new Error('Bilibili guard namespace is not initialized');

  function createSessionCache({storageArea, now}) {
    if (!storageArea?.get || !storageArea?.set || typeof now !== 'function') {
      throw new TypeError('Session cache dependencies are invalid');
    }

    async function read(key) {
      const entry = (await storageArea.get(key))?.[key];
      if (
        !entry
        || typeof entry !== 'object'
        || !Object.prototype.hasOwnProperty.call(entry, 'value')
        || !Number.isSafeInteger(entry.fetchedAt)
        || !Number.isSafeInteger(entry.expiresAt)
        || entry.expiresAt < entry.fetchedAt
      ) {
        return {state: 'missing', value: null};
      }
      return {
        state: entry.expiresAt > now() ? 'fresh' : 'stale',
        value: entry.value,
        fetchedAt: entry.fetchedAt,
        expiresAt: entry.expiresAt,
      };
    }

    async function write(key, value, ttlMs) {
      if (typeof key !== 'string' || !Number.isSafeInteger(ttlMs) || ttlMs <= 0) {
        throw new TypeError('Session cache write is invalid');
      }
      const fetchedAt = now();
      const expiresAt = fetchedAt + ttlMs;
      if (!Number.isSafeInteger(fetchedAt) || !Number.isSafeInteger(expiresAt)) {
        throw new TypeError('Session cache clock is invalid');
      }
      await storageArea.set({[key]: {value, fetchedAt, expiresAt}});
      return {value, fetchedAt, expiresAt};
    }

    return Object.freeze({read, write});
  }

  function coalesce(inFlight, key, operation) {
    if (inFlight.has(key)) return inFlight.get(key);
    const promise = Promise.resolve()
      .then(operation)
      .finally(() => {
        if (inFlight.get(key) === promise) inFlight.delete(key);
      });
    inFlight.set(key, promise);
    return promise;
  }

  runtime.cache = Object.freeze({createSessionCache, coalesce});
})();
