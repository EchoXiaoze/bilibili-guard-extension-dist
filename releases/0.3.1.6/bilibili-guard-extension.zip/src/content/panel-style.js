(() => {
  const runtime = globalThis.__BILIBILI_GUARD__;
  if (!runtime) throw new Error('Bilibili guard namespace is not initialized');

  runtime.panelStyle = Object.freeze({
    css: String.raw`
:host {
  all: initial;
  position: fixed;
  top: 96px;
  right: 16px;
  width: min(420px, calc(100vw - 32px));
  max-height: calc(100vh - 16px);
  z-index: 2147483000;
  color-scheme: light;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
}

:host(.is-minimized) {
  width: min(320px, calc(100vw - 16px));
}

*, *::before, *::after {
  box-sizing: border-box;
}

.guard-panel {
  display: flex;
  max-height: calc(100vh - 16px);
  flex-direction: column;
  overflow: hidden;
  color: #2f3138;
  background: rgba(255, 255, 255, 0.98);
  border: 1px solid rgba(251, 114, 153, 0.24);
  border-radius: 16px;
  box-shadow: 0 14px 36px rgba(28, 31, 38, 0.18);
  backdrop-filter: blur(14px);
}

.guard-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  padding: 16px 16px 12px;
  flex: 0 0 auto;
  background: linear-gradient(135deg, rgba(251, 114, 153, 0.13), rgba(0, 174, 236, 0.08));
  cursor: grab;
  touch-action: none;
  user-select: none;
}

.guard-header:active {
  cursor: grabbing;
}

.guard-header .guard-creator-name {
  cursor: pointer;
  user-select: text;
}

.guard-heading,
.guard-count,
.guard-member-name,
.guard-creator-name {
  margin: 0;
}

.guard-heading {
  color: #18191c;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.4;
}

.guard-creator {
  min-width: 0;
  margin-top: 5px;
  color: #61666d;
  font-size: 12px;
  line-height: 1.5;
}

.guard-creator-name,
.guard-member-name {
  color: #18191c;
  text-decoration: none;
  overflow-wrap: anywhere;
}

.guard-creator-name:hover,
.guard-member-name:hover {
  color: #fb7299;
}

.guard-count-wrap {
  flex: 0 0 auto;
  min-width: 84px;
  text-align: right;
}

.guard-count {
  color: #fb7299;
  font-size: 26px;
  font-weight: 750;
  line-height: 1;
}

.guard-count-label {
  display: block;
  margin-top: 5px;
  color: #9499a0;
  font-size: 11px;
}

.guard-toggle {
  appearance: none;
  flex: 0 0 auto;
  min-height: 30px;
  padding: 5px 8px;
  color: #61666d;
  background: rgba(255, 255, 255, 0.7);
  border: 1px solid #dfe2e5;
  border-radius: 8px;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  user-select: text;
}

.guard-toggle:focus-visible {
  outline: 3px solid rgba(0, 174, 236, 0.28);
  outline-offset: 2px;
}

.guard-status {
  min-height: 35px;
  padding: 10px 16px;
  color: #61666d;
  background: #f6f7f8;
  border-top: 1px solid #eef0f2;
  border-bottom: 1px solid #eef0f2;
  font-size: 12px;
  line-height: 1.3;
}

.guard-status.is-error {
  color: #d54941;
  background: #fff5f5;
}

.guard-status.is-stale,
.guard-status.is-cooldown {
  color: #8a5a00;
  background: #fff9e8;
}

.guard-update {
  padding: 9px 16px;
  color: #005a85;
  background: #eef9ff;
  border-bottom: 1px solid #d8f0fb;
  font-size: 12px;
  line-height: 1.35;
}

.guard-update[hidden] {
  display: none;
}

.guard-update-link {
  color: inherit;
  font-weight: 650;
  text-decoration: none;
}

.guard-update-link:hover {
  text-decoration: underline;
}

.guard-actions {
  display: flex;
  gap: 8px;
  padding: 12px 16px;
}

.guard-button {
  appearance: none;
  min-height: 34px;
  padding: 7px 14px;
  color: #fff;
  background: #fb7299;
  border: 1px solid #fb7299;
  border-radius: 9px;
  cursor: pointer;
  font: inherit;
  font-size: 13px;
  font-weight: 650;
  transition: transform 120ms ease, opacity 120ms ease, background 120ms ease;
}

.guard-button.is-secondary {
  color: #61666d;
  background: #fff;
  border-color: #dfe2e5;
}

.guard-button:hover:not(:disabled) {
  transform: translateY(-1px);
}

.guard-button:focus-visible,
.guard-member-name:focus-visible,
.guard-creator-name:focus-visible {
  outline: 3px solid rgba(0, 174, 236, 0.28);
  outline-offset: 2px;
}

.guard-button:disabled {
  cursor: wait;
  opacity: 0.55;
}

.guard-list {
  min-height: 0;
  flex: 1 1 auto;
  max-height: 70vh;
  overflow-x: hidden;
  overflow-y: auto;
  padding: 0 12px 14px;
  scrollbar-width: thin;
}

:host(.is-minimized) .guard-status,
:host(.is-minimized) .guard-update,
:host(.is-minimized) .guard-actions,
:host(.is-minimized) .guard-list {
  display: none;
}

.guard-empty {
  padding: 24px 12px 28px;
  color: #9499a0;
  font-size: 13px;
  text-align: center;
}

.guard-member {
  display: grid;
  grid-template-columns: 76px minmax(0, 1fr);
  gap: 12px;
  min-width: 0;
  padding: 12px 4px;
  border-top: 1px solid #eef0f2;
}

.guard-avatar-shell {
  display: block;
  position: relative;
  width: 76px;
  height: 76px;
  overflow: visible;
}

.guard-avatar-link {
  border-radius: 50%;
  cursor: zoom-in;
  text-decoration: none;
}

.guard-avatar-link:focus-visible {
  outline: 3px solid rgba(0, 174, 236, 0.28);
  outline-offset: 2px;
}

.guard-avatar-base,
.guard-avatar {
  position: absolute;
  top: 6px;
  left: 5px;
  width: 66px;
  height: 66px;
}

.guard-avatar-base {
  display: grid;
  place-items: center;
  overflow: hidden;
  color: #9499a0;
  background: linear-gradient(135deg, #f1f2f3, #e3e5e7);
  border-radius: 50%;
  font-size: 25px;
}

.guard-avatar {
  z-index: 1;
  object-fit: cover;
  border-radius: 50%;
}

.guard-avatar-shell.is-placeholder .guard-avatar {
  display: none;
}

.guard-frame {
  position: absolute;
  inset: 0;
  width: 76px;
  height: 76px;
  z-index: 2;
  object-fit: contain;
  pointer-events: none;
}

.guard-member-body {
  min-width: 0;
  padding: 2px 0;
}

.guard-member-top {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 8px;
}

.guard-member-name {
  min-width: 0;
  font-size: 14px;
  font-weight: 700;
  line-height: 1.4;
}

.guard-rank {
  flex: 0 0 auto;
  color: #9499a0;
  font-size: 11px;
}

.guard-member-meta,
.guard-medal {
  margin-top: 5px;
  color: #61666d;
  font-size: 12px;
  line-height: 1.45;
  overflow-wrap: anywhere;
}

.guard-tier {
  display: inline-block;
  margin-right: 7px;
  padding: 2px 7px;
  color: #a64b6a;
  background: #fff0f5;
  border-radius: 999px;
  font-weight: 650;
}

.guard-medal {
  color: #8a5a00;
}

@media (max-width: 460px) {
  :host {
    top: 72px;
    right: 16px;
  }

  .guard-header,
  .guard-actions {
    padding-right: 12px;
    padding-left: 12px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .guard-button {
    transition: none;
  }
}
`,
  });
})();
